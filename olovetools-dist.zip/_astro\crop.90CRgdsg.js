import{c as o}from"./createLucideIcon.D7mwnnQi.js";const a=[["path",{d:"M6 2v14a2 2 0 0 0 2 2h14",key:"ron5a4"}],["path",{d:"M18 22V8a2 2 0 0 0-2-2H2",key:"7s9ehn"}]],e=o("crop",a);export{e as C};
