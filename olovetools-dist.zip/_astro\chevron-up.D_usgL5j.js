import{c as o}from"./createLucideIcon.D7mwnnQi.js";const c=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],n=o("chevron-up",c);export{n as C};
