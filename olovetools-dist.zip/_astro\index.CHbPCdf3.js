import{c as e}from"./createLucideIcon.D7mwnnQi.js";const o=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],p=e("chevron-down",o),s={privacy:{title:"Privacy Policy",description:"Comprehensive privacy policy for oLoveTools.",content:`
      <h2>1. Introduction</h2>
      <p>Your privacy is important to us. It is oLoveTools' policy to respect your privacy regarding any information we may collect from you across our website, olovetools.com, and other sites we own and operate.</p>
      <br/>
      <h2>2. Information we collect</h2>
      <p>We only ask for personal information when we truly need it to provide a service to you. We collect it by fair and lawful means, with your knowledge and consent. We also let you know why we’re collecting it and how it will be used.</p>
      <p>For most of our tools (such as Clipy, ClipBolt, FormatFlow, and PasteSnap), processing happens entirely in your browser. We do not store your clips, images, or formatted code on our servers.</p>
      <br/>
      <h2>3. Third-Party Services and Ads</h2>
      <p>Our website uses Google AdSense to serve ads. Google uses cookies to serve ads based on a user's prior visits to our website or other websites. Google's use of advertising cookies enables it and its partners to serve ads to our users based on their visit to our sites and/or other sites on the Internet.</p>
      <br/>
      <h2>4. Data Retention</h2>
      <p>We only retain collected information for as long as necessary to provide you with your requested service. What data we store, we’ll protect within commercially acceptable means to prevent loss and theft, as well as unauthorized access, disclosure, copying, use or modification.</p>
      <br/>
      <h2>5. User Rights</h2>
      <p>You are free to refuse our request for your personal information, with the understanding that we may be unable to provide you with some of your desired services.</p>
    `},terms:{title:"Terms of Service",description:"Terms and conditions for using oLoveTools.",content:`
      <h2>1. Terms</h2>
      <p>By accessing the website at oLoveTools, you are agreeing to be bound by these terms of service, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site.</p>
      <br/>
      <h2>2. Use License</h2>
      <p>Permission is granted to temporarily download one copy of the materials (information or software) on oLoveTools' website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title.</p>
      <br/>
      <h2>3. Disclaimer</h2>
      <p>The materials on oLoveTools' website are provided on an 'as is' basis. oLoveTools makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
      <br/>
      <h2>4. Limitations</h2>
      <p>In no event shall oLoveTools or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on oLoveTools' website.</p>
      <br/>
      <h2>5. Third-Party Content</h2>
      <p>Some of our tools (e.g., Clipy, ClipBolt) interact with third-party APIs (like Twitch). By using these tools, you must also comply with the respective Terms of Service of those third-party platforms. We do not host or own the media content retrieved through these APIs.</p>
    `},cookies:{title:"Cookies Policy",description:"Information about our use of cookies and tracking technologies.",content:`
      <h2>1. What are cookies?</h2>
      <p>Cookies are small text files that are stored on your computer or mobile device when you visit a website. They are widely used in order to make websites work, or work more efficiently, as well as to provide information to the owners of the site.</p>
      <br/>
      <h2>2. How we use cookies</h2>
      <p>We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. We use essential cookies to remember your language preference and other settings.</p>
      <br/>
      <h2>3. Google AdSense Cookies</h2>
      <p>We use Google AdSense to serve ads on our site. Google's use of the DART cookie enables it to serve ads to our users based on their visit to our site and other sites on the Internet. Users may opt out of the use of the DART cookie by visiting the Google ad and content network privacy policy.</p>
      <br/>
      <h2>4. Managing Cookies</h2>
      <p>You can set your browser to refuse all or some browser cookies, or to alert you when websites set or access cookies. If you disable or refuse cookies, please note that some parts of this website may become inaccessible or not function properly.</p>
    `},about:{title:"About oLoveTools",description:"Learn more about our mission and the tools we provide.",content:`
      <h2>Our Mission</h2>
      <p>oLoveTools is a comprehensive suite of free, high-quality online utilities designed to simplify the daily tasks of developers, designers, content creators, and everyday users. Our mission is to provide powerful tools that are fast, secure, and accessible directly from your browser without the need for installations or registrations.</p>
      <br/>
      <h2>Our Philosophy</h2>
      <p>We believe in privacy and efficiency. Whenever possible, our tools are designed to process data locally on your device. This means your files, images, and code snippets never leave your computer, ensuring maximum privacy and blazing-fast performance.</p>
      <br/>
      <h2>The Tools</h2>
      <ul>
        <li><strong>Clipy & ClipBolt:</strong> Discover, organize, and download your favorite Twitch clips easily.</li>
        <li><strong>FormatFlow:</strong> A versatile tool for formatting and converting various types of code and data.</li>
        <li><strong>PasteSnap:</strong> Instantly capture and manage your clipboard images with high quality.</li>
      </ul>
      <br/>
      <p>We are constantly evolving and adding new features to our platform. Thank you for choosing oLoveTools!</p>
    `},nav:{home:"Home",privacy:"Privacy",terms:"Terms",cookies:"Cookies",about:"About"}},i={privacy:{title:"Política de Privacidad",description:"Política de privacidad detallada para oLoveTools.",content:`
      <h2>1. Introducción</h2>
      <p>Su privacidad es importante para nosotros. Es política de oLoveTools respetar su privacidad con respecto a cualquier información que podamos recopilar de usted a través de nuestro sitio web, olovetools.com, y otros sitios que poseemos y operamos.</p>
      <br/>
      <h2>2. Información que recopilamos</h2>
      <p>Solo solicitamos información personal cuando realmente la necesitamos para brindarle un servicio. La recopilamos por medios justos y legales, con su conocimiento y consentimiento. También le informamos por qué la recopilamos y cómo se utilizará.</p>
      <p>Para la mayoría de nuestras herramientas (como Clipy, ClipBolt, FormatFlow y PasteSnap), el procesamiento se realiza completamente en su navegador. No almacenamos sus clips, imágenes ni código en nuestros servidores.</p>
      <br/>
      <h2>3. Servicios de terceros y anuncios</h2>
      <p>Nuestro sitio web utiliza Google AdSense para publicar anuncios. Google utiliza cookies para mostrar anuncios basados en las visitas anteriores de un usuario a nuestro sitio web u otros sitios web. El uso de cookies publicitarias por parte de Google le permite a él y a sus socios publicar anuncios para nuestros usuarios basados en su visita a nuestros sitios y/u otros sitios en Internet.</p>
      <br/>
      <h2>4. Retención de datos</h2>
      <p>Solo retenemos la información recopilada durante el tiempo necesario para brindarle el servicio solicitado. Los datos que almacenamos los protegeremos dentro de medios comercialmente aceptables para evitar pérdidas y robos, así como el acceso, divulgación, copia, uso o modificación no autorizados.</p>
      <br/>
      <h2>5. Derechos del usuario</h2>
      <p>Usted es libre de rechazar nuestra solicitud de su información personal, con el entendimiento de que es posible que no podamos brindarle algunos de los servicios que desea.</p>
    `},terms:{title:"Términos de Servicio",description:"Términos y condiciones para el uso de oLoveTools.",content:`
      <h2>1. Términos</h2>
      <p>Al acceder al sitio web en oLoveTools, usted acepta estar sujeto a estos términos de servicio, todas las leyes y regulaciones aplicables, y acepta que es responsable del cumplimiento de las leyes locales aplicables. Si no está de acuerdo con alguno de estos términos, tiene prohibido usar o acceder a este sitio.</p>
      <br/>
      <h2>2. Licencia de uso</h2>
      <p>Se otorga permiso para descargar temporalmente una copia de los materiales (información o software) en el sitio web de oLoveTools solo para visualización transitoria personal y no comercial. Esta es la concesión de una licencia, no una transferencia de título.</p>
      <br/>
      <h2>3. Descargo de responsabilidad</h2>
      <p>Los materiales en el sitio web de oLoveTools se proporcionan "tal cual". oLoveTools no ofrece garantías, expresas o implícitas, y por la presente renuncia y niega todas las demás garantías, incluidas, entre otras, las garantías implícitas o las condiciones de comerciabilidad, idoneidad para un propósito particular o no infracción de la propiedad intelectual u otra violación de derechos.</p>
      <br/>
      <h2>4. Limitaciones</h2>
      <p>En ningún caso oLoveTools o sus proveedores serán responsables de ningún daño (incluidos, entre otros, daños por pérdida de datos o ganancias, o debido a la interrupción del negocio) que surja del uso o la imposibilidad de usar los materiales en el sitio web de oLoveTools.</p>
      <br/>
      <h2>5. Contenido de terceros</h2>
      <p>Algunas de nuestras herramientas (por ejemplo, Clipy, ClipBolt) interactúan con API de terceros (como Twitch). Al utilizar estas herramientas, también debe cumplir con los Términos de Servicio respectivos de esas plataformas de terceros. No alojamos ni somos dueños del contenido multimedia recuperado a través de estas API.</p>
    `},cookies:{title:"Política de Cookies",description:"Información sobre nuestro uso de cookies y tecnologías de seguimiento.",content:`
      <h2>1. ¿Qué son las cookies?</h2>
      <p>Las cookies son pequeños archivos de texto que se almacenan en su computadora o dispositivo móvil cuando visita un sitio web. Se utilizan ampliamente para que los sitios web funcionen, o funcionen de manera más eficiente, así como para proporcionar información a los propietarios del sitio.</p>
      <br/>
      <h2>2. Cómo usamos las cookies</h2>
      <p>Utilizamos cookies para mejorar su experiencia de navegación, mostrar anuncios o contenido personalizados y analizar nuestro tráfico. Usamos cookies esenciales para recordar su preferencia de idioma y otras configuraciones.</p>
      <br/>
      <h2>3. Cookies de Google AdSense</h2>
      <p>Utilizamos Google AdSense para publicar anuncios en nuestro sitio. El uso de la cookie DART por parte de Google le permite publicar anuncios para nuestros usuarios basados en su visita a nuestro sitio y otros sitios en Internet. Los usuarios pueden optar por no usar la cookie DART visitando la política de privacidad de la red de contenido y anuncios de Google.</p>
      <br/>
      <h2>4. Gestión de cookies</h2>
      <p>Puede configurar su navegador para rechazar todas o algunas cookies del navegador, o para que le avise cuando los sitios web configuren o accedan a las cookies. Si deshabilita o rechaza las cookies, tenga en cuenta que algunas partes de este sitio web pueden volverse inaccesibles o no funcionar correctamente.</p>
    `},about:{title:"Sobre oLoveTools",description:"Conozca más sobre nuestra misión y las herramientas que ofrecemos.",content:`
      <h2>Nuestra Misión</h2>
      <p>oLoveTools es un conjunto completo de utilidades en línea gratuitas y de alta calidad diseñadas para simplificar las tareas diarias de desarrolladores, diseñadores, creadores de contenido y usuarios cotidianos. Nuestra misión es proporcionar herramientas potentes que sean rápidas, seguras y accesibles directamente desde su navegador sin necesidad de instalaciones ni registros.</p>
      <br/>
      <h2>Nuestra Filosofía</h2>
      <p>Creemos en la privacidad y la eficiencia. Siempre que es posible, nuestras herramientas están diseñadas para procesar datos localmente en su dispositivo. Esto significa que sus archivos, imágenes y fragmentos de código nunca salen de su computadora, lo que garantiza la máxima privacidad y un rendimiento ultrarrápido.</p>
      <br/>
      <h2>Las Herramientas</h2>
      <ul>
        <li><strong>Clipy & ClipBolt:</strong> Descubra, organice y descargue sus clips favoritos de Twitch fácilmente.</li>
        <li><strong>FormatFlow:</strong> Una herramienta versátil para formatear y convertir varios tipos de código y datos.</li>
        <li><strong>PasteSnap:</strong> Capture y gestione instantáneamente las imágenes de su portapapeles con alta calidad.</li>
      </ul>
      <br/>
      <p>Estamos en constante evolución y agregando nuevas funciones a nuestra plataforma. ¡Gracias por elegir oLoveTools!</p>
    `},nav:{home:"Inicio",privacy:"Privacidad",terms:"Términos",cookies:"Cookies",about:"Nosotros"}},n={privacy:{title:"Politique de Confidentialité",description:"Politique de confidentialité complète pour oLoveTools.",content:`
      <h2>1. Introduction</h2>
      <p>Votre vie privée est importante pour nous. La politique d'oLoveTools est de respecter votre vie privée concernant toute information que nous pouvons collecter auprès de vous sur notre site Web, olovetools.com, et d'autres sites que nous possédons et exploitons.</p>
      <br/>
      <h2>2. Les informations que nous collectons</h2>
      <p>Nous ne demandons des informations personnelles que lorsque nous en avons vraiment besoin pour vous fournir un service. Nous les collectons par des moyens justes et légaux, avec votre connaissance et votre consentement. Nous vous informons également de la raison pour laquelle nous les collectons et de la manière dont elles seront utilisées.</p>
      <p>Pour la plupart de nos outils (tels que Clipy, ClipBolt, FormatFlow et PasteSnap), le traitement s'effectue entièrement dans votre navigateur. Nous ne stockons pas vos clips, images ou codes formatés sur nos serveurs.</p>
      <br/>
      <h2>3. Services tiers et publicités</h2>
      <p>Notre site Web utilise Google AdSense pour diffuser des annonces. Google utilise des cookies pour diffuser des annonces en fonction des visites antérieures d'un utilisateur sur notre site Web ou sur d'autres sites Web. L'utilisation de cookies publicitaires par Google lui permet, ainsi qu'à ses partenaires, de diffuser des annonces auprès de nos utilisateurs en fonction de leur visite sur nos sites et/ou d'autres sites sur Internet.</p>
      <br/>
      <h2>4. Conservation des données</h2>
      <p>Nous ne conservons les informations collectées que le temps nécessaire pour vous fournir le service demandé. Les données que nous stockons seront protégées par des moyens commercialement acceptables pour éviter la perte et le vol, ainsi que l'accès, la divulgation, la copie, l'utilisation ou la modification non autorisés.</p>
      <br/>
      <h2>5. Droits des utilisateurs</h2>
      <p>Vous êtes libre de refuser notre demande d'informations personnelles, étant entendu que nous pourrions ne pas être en mesure de vous fournir certains des services souhaités.</p>
    `},terms:{title:"Conditions d'Utilisation",description:"Conditions générales d'utilisation d'oLoveTools.",content:`
      <h2>1. Conditions</h2>
      <p>En accédant au site Web d'oLoveTools, vous acceptez d'être lié par ces conditions d'utilisation, toutes les lois et réglementations applicables, et convenez que vous êtes responsable du respect des lois locales applicables. Si vous n'êtes pas d'accord avec l'une de ces conditions, il vous est interdit d'utiliser ou d'accéder à ce site.</p>
      <br/>
      <h2>2. Licence d'utilisation</h2>
      <p>L'autorisation est accordée de télécharger temporairement une copie du matériel (informations ou logiciels) sur le site Web d'oLoveTools pour une visualisation transitoire personnelle et non commerciale uniquement. Il s'agit de l'octroi d'une licence, et non d'un transfert de titre.</p>
      <br/>
      <h2>3. Avis de non-responsabilité</h2>
      <p>Le matériel sur le site Web d'oLoveTools est fourni « tel quel ». oLoveTools ne donne aucune garantie, expresse ou implicite, et rejette et nie par la présente toutes les autres garanties, y compris, sans limitation, les garanties implicites ou les conditions de qualité marchande, d'adéquation à un usage particulier ou de non-violation de la propriété intellectuelle ou autre violation des droits.</p>
      <br/>
      <h2>4. Limites</h2>
      <p>En aucun cas, oLoveTools ou ses fournisseurs ne pourront être tenus responsables de tout dommage (y compris, sans limitation, les dommages pour perte de données ou de profit, ou en raison d'une interruption d'activité) découlant de l'utilisation ou de l'incapacité d'utiliser le matériel sur le site Web d'oLoveTools.</p>
      <br/>
      <h2>5. Contenu tiers</h2>
      <p>Certains de nos outils (ex: Clipy, ClipBolt) interagissent avec des API tierces (comme Twitch). En utilisant ces outils, vous devez également vous conformer aux Conditions d'Utilisation respectives de ces plateformes tierces. Nous n'hébergeons ni ne possédons le contenu multimédia récupéré via ces API.</p>
    `},cookies:{title:"Politique relative aux Cookies",description:"Informations sur notre utilisation des cookies et des technologies de suivi.",content:`
      <h2>1. Que sont les cookies ?</h2>
      <p>Les cookies sont de petits fichiers texte qui sont stockés sur votre ordinateur ou appareil mobile lorsque vous visitez un site Web. Ils sont largement utilisés pour faire fonctionner les sites Web, ou pour les faire fonctionner plus efficacement, ainsi que pour fournir des informations aux propriétaires du site.</p>
      <br/>
      <h2>2. Comment nous utilisons les cookies</h2>
      <p>Nous utilisons des cookies pour améliorer votre expérience de navigation, diffuser des annonces ou des contenus personnalisés et analyser notre trafic. Nous utilisons des cookies essentiels pour mémoriser votre préférence linguistique et d'autres paramètres.</p>
      <br/>
      <h2>3. Cookies Google AdSense</h2>
      <p>Nous utilisons Google AdSense pour diffuser des annonces sur notre site. L'utilisation du cookie DART par Google lui permet de diffuser des annonces à nos utilisateurs en fonction de leur visite sur notre site et d'autres sites sur Internet. Les utilisateurs peuvent refuser l'utilisation du cookie DART en visitant la politique de confidentialité du réseau de contenu et d'annonces Google.</p>
      <br/>
      <h2>4. Gestion des cookies</h2>
      <p>Vous pouvez configurer votre navigateur pour refuser tout ou partie des cookies du navigateur, ou pour vous alerter lorsque des sites Web définissent ou accèdent à des cookies. Si vous désactivez ou refusez les cookies, veuillez noter que certaines parties de ce site Web peuvent devenir inaccessibles ou ne pas fonctionner correctement.</p>
    `},about:{title:"À propos d'oLoveTools",description:"En savoir plus sur notre mission et les outils que nous proposons.",content:`
      <h2>Notre Mission</h2>
      <p>oLoveTools est une suite complète d'utilitaires en ligne gratuits et de haute qualité conçus pour simplifier les tâches quotidiennes des développeurs, concepteurs, créateurs de contenu et utilisateurs. Notre mission est de fournir des outils puissants, rapides, sécurisés et accessibles directement depuis votre navigateur sans nécessiter d'installation ni d'inscription.</p>
      <br/>
      <h2>Notre Philosophie</h2>
      <p>Nous croyons en la confidentialité et l'efficacité. Chaque fois que possible, nos outils sont conçus pour traiter les données localement sur votre appareil. Cela signifie que vos fichiers, images et extraits de code ne quittent jamais votre ordinateur, garantissant une confidentialité maximale et des performances ultra-rapides.</p>
      <br/>
      <h2>Les Outils</h2>
      <ul>
        <li><strong>Clipy & ClipBolt:</strong> Découvrez, organisez et téléchargez facilement vos clips Twitch préférés.</li>
        <li><strong>FormatFlow:</strong> Un outil polyvalent pour formater et convertir divers types de données et de codes.</li>
        <li><strong>PasteSnap:</strong> Capturez et gérez instantanément les images de votre presse-papiers avec une haute qualité.</li>
      </ul>
      <br/>
      <p>Nous évoluons constamment et ajoutons de nouvelles fonctionnalités à notre plateforme. Merci d'avoir choisi oLoveTools !</p>
    `},nav:{home:"Accueil",privacy:"Confidentialité",terms:"Conditions",cookies:"Cookies",about:"À propos"}},r={privacy:{title:"Datenschutzrichtlinie",description:"Umfassende Datenschutzrichtlinie für oLoveTools.",content:`
      <h2>1. Einleitung</h2>
      <p>Ihre Privatsphäre ist uns wichtig. Es ist die Richtlinie von oLoveTools, Ihre Privatsphäre in Bezug auf alle Informationen zu respektieren, die wir auf unserer Website olovetools.com und anderen von uns betriebenen Websites erfassen.</p>
      <br/>
      <h2>2. Informationen, die wir sammeln</h2>
      <p>Wir fragen nur nach persönlichen Informationen, wenn wir sie wirklich benötigen, um Ihnen einen Service zu bieten. Wir sammeln sie auf faire und legale Weise mit Ihrem Wissen und Ihrer Zustimmung. Wir teilen Ihnen auch mit, warum wir sie sammeln und wie sie verwendet werden.</p>
      <p>Bei den meisten unserer Tools (wie Clipy, ClipBolt, FormatFlow und PasteSnap) erfolgt die Verarbeitung vollständig in Ihrem Browser. Wir speichern Ihre Clips, Bilder oder formatierten Codes nicht auf unseren Servern.</p>
      <br/>
      <h2>3. Dienste Dritter und Anzeigen</h2>
      <p>Unsere Website verwendet Google AdSense, um Anzeigen zu schalten. Google verwendet Cookies, um Anzeigen basierend auf früheren Besuchen eines Benutzers auf unserer oder anderen Websites zu schalten. Die Verwendung von Werbe-Cookies durch Google ermöglicht es Google und seinen Partnern, Anzeigen für unsere Nutzer basierend auf deren Besuch auf unseren und/oder anderen Websites im Internet zu schalten.</p>
      <br/>
      <h2>4. Datenspeicherung</h2>
      <p>Wir speichern gesammelte Informationen nur so lange, wie es zur Bereitstellung des von Ihnen angeforderten Dienstes erforderlich ist. Die von uns gespeicherten Daten schützen wir mit kommerziell akzeptablen Mitteln, um Verlust und Diebstahl sowie unbefugten Zugriff, Offenlegung, Kopieren, Verwendung oder Änderung zu verhindern.</p>
      <br/>
      <h2>5. Benutzerrechte</h2>
      <p>Es steht Ihnen frei, unsere Anfrage nach Ihren persönlichen Daten abzulehnen, mit der Maßgabe, dass wir Ihnen möglicherweise einige Ihrer gewünschten Dienste nicht anbieten können.</p>
    `},terms:{title:"Nutzungsbedingungen",description:"Allgemeine Geschäftsbedingungen für die Nutzung von oLoveTools.",content:`
      <h2>1. Bedingungen</h2>
      <p>Durch den Zugriff auf die Website von oLoveTools stimmen Sie zu, an diese Nutzungsbedingungen sowie alle geltenden Gesetze und Vorschriften gebunden zu sein, und stimmen zu, dass Sie für die Einhaltung geltender lokaler Gesetze verantwortlich sind. Wenn Sie mit einer dieser Bedingungen nicht einverstanden sind, ist Ihnen die Nutzung dieser Website untersagt.</p>
      <br/>
      <h2>2. Nutzungslizenz</h2>
      <p>Es wird die Erlaubnis erteilt, vorübergehend eine Kopie der Materialien (Informationen oder Software) auf der Website von oLoveTools herunterzuladen, und zwar ausschließlich für die persönliche, nicht kommerzielle vorübergehende Betrachtung. Dies ist die Gewährung einer Lizenz, keine Eigentumsübertragung.</p>
      <br/>
      <h2>3. Haftungsausschluss</h2>
      <p>Die Materialien auf der Website von oLoveTools werden "wie besehen" zur Verfügung gestellt. oLoveTools gibt keine ausdrücklichen oder stillschweigenden Garantien ab und lehnt hiermit alle anderen Garantien ab, einschließlich, aber nicht beschränkt auf stillschweigende Garantien oder Bedingungen der Marktgängigkeit, Eignung für einen bestimmten Zweck oder Nichtverletzung von geistigem Eigentum oder anderen Rechtsverletzungen.</p>
      <br/>
      <h2>4. Einschränkungen</h2>
      <p>In keinem Fall haften oLoveTools oder seine Lieferanten für Schäden (einschließlich, aber nicht beschränkt auf Schäden durch Daten- oder Gewinnverlust oder aufgrund von Betriebsunterbrechungen), die sich aus der Nutzung oder der Unmöglichkeit der Nutzung der Materialien auf der Website von oLoveTools ergeben.</p>
      <br/>
      <h2>5. Inhalte Dritter</h2>
      <p>Einige unserer Tools (z. B. Clipy, ClipBolt) interagieren mit APIs von Drittanbietern (wie Twitch). Durch die Nutzung dieser Tools müssen Sie auch die jeweiligen Nutzungsbedingungen dieser Drittanbieter-Plattformen einhalten. Wir hosten oder besitzen die über diese APIs abgerufenen Medieninhalte nicht.</p>
    `},cookies:{title:"Cookie-Richtlinie",description:"Informationen über unsere Verwendung von Cookies und Tracking-Technologien.",content:`
      <h2>1. Was sind Cookies?</h2>
      <p>Cookies sind kleine Textdateien, die auf Ihrem Computer oder Mobilgerät gespeichert werden, wenn Sie eine Website besuchen. Sie werden häufig verwendet, um Websites funktionsfähig oder effizienter zu machen sowie den Eigentümern der Website Informationen bereitzustellen.</p>
      <br/>
      <h2>2. Wie wir Cookies verwenden</h2>
      <p>Wir verwenden Cookies, um Ihr Surferlebnis zu verbessern, personalisierte Anzeigen oder Inhalte bereitzustellen und unseren Datenverkehr zu analysieren. Wir verwenden wesentliche Cookies, um Ihre Spracheinstellung und andere Einstellungen zu speichern.</p>
      <br/>
      <h2>3. Google AdSense-Cookies</h2>
      <p>Wir verwenden Google AdSense, um Anzeigen auf unserer Website zu schalten. Die Verwendung des DART-Cookies durch Google ermöglicht es, unseren Benutzern Anzeigen zu schalten, die auf ihrem Besuch auf unserer Website und anderen Websites im Internet basieren. Benutzer können die Verwendung des DART-Cookies ablehnen, indem sie die Datenschutzrichtlinie des Google-Anzeigen- und Content-Netzwerks besuchen.</p>
      <br/>
      <h2>4. Cookies verwalten</h2>
      <p>Sie können Ihren Browser so einstellen, dass alle oder einige Browser-Cookies abgelehnt werden oder dass Sie gewarnt werden, wenn Websites Cookies setzen oder darauf zugreifen. Wenn Sie Cookies deaktivieren oder ablehnen, beachten Sie bitte, dass einige Teile dieser Website möglicherweise unzugänglich werden oder nicht richtig funktionieren.</p>
    `},about:{title:"Über oLoveTools",description:"Erfahren Sie mehr über unsere Mission und die von uns angebotenen Tools.",content:`
      <h2>Unsere Mission</h2>
      <p>oLoveTools ist eine umfassende Suite kostenloser, hochwertiger Online-Dienstprogramme, die die täglichen Aufgaben von Entwicklern, Designern, Inhaltserstellern und alltäglichen Benutzern vereinfachen sollen. Unsere Mission ist es, leistungsstarke Tools bereitzustellen, die schnell, sicher und direkt über Ihren Browser zugänglich sind, ohne dass Installationen oder Registrierungen erforderlich sind.</p>
      <br/>
      <h2>Unsere Philosophie</h2>
      <p>Wir glauben an Datenschutz und Effizienz. Wann immer möglich, sind unsere Tools so konzipiert, dass sie Daten lokal auf Ihrem Gerät verarbeiten. Dies bedeutet, dass Ihre Dateien, Bilder und Code-Snippets Ihren Computer nie verlassen, was maximale Privatsphäre und rasante Leistung gewährleistet.</p>
      <br/>
      <h2>Die Werkzeuge</h2>
      <ul>
        <li><strong>Clipy & ClipBolt:</strong> Entdecken, organisieren und laden Sie Ihre Lieblings-Twitch-Clips ganz einfach herunter.</li>
        <li><strong>FormatFlow:</strong> Ein vielseitiges Tool zum Formatieren und Konvertieren verschiedener Arten von Code und Daten.</li>
        <li><strong>PasteSnap:</strong> Erfassen und verwalten Sie Ihre Zwischenablage-Bilder sofort in hoher Qualität.</li>
      </ul>
      <br/>
      <p>Wir entwickeln uns ständig weiter und fügen unserer Plattform neue Funktionen hinzu. Vielen Dank, dass Sie sich für oLoveTools entschieden haben!</p>
    `},nav:{home:"Startseite",privacy:"Datenschutz",terms:"Bedingungen",cookies:"Cookies",about:"Über uns"}},t={privacy:{title:"Política de Privacidade",description:"Política de privacidade abrangente para oLoveTools.",content:`
      <h2>1. Introdução</h2>
      <p>A sua privacidade é importante para nós. É política da oLoveTools respeitar a sua privacidade em relação a qualquer informação que possamos coletar de você em nosso site, olovetools.com, e outros sites que possuímos e operamos.</p>
      <br/>
      <h2>2. Informações que coletamos</h2>
      <p>Solicitamos informações pessoais apenas quando realmente precisamos delas para lhe fornecer um serviço. Fazemo-lo por meios justos e legais, com o seu conhecimento e consentimento. Também informamos o motivo de estarmos coletando e como elas serão usadas.</p>
      <p>Para a maioria de nossas ferramentas (como Clipy, ClipBolt, FormatFlow e PasteSnap), o processamento ocorre inteiramente em seu navegador. Não armazenamos seus clipes, imagens ou códigos formatados em nossos servidores.</p>
      <br/>
      <h2>3. Serviços de terceiros e anúncios</h2>
      <p>O nosso site utiliza o Google AdSense para veicular anúncios. O Google usa cookies para veicular anúncios com base em visitas anteriores de um usuário ao nosso ou a outros sites. O uso de cookies de publicidade pelo Google permite que ele e seus parceiros veiculem anúncios para nossos usuários com base em sua visita a nossos sites e/ou outros sites na Internet.</p>
      <br/>
      <h2>4. Retenção de dados</h2>
      <p>Apenas retemos as informações coletadas pelo tempo necessário para fornecer o serviço solicitado. Os dados que armazenamos, os protegeremos por meios comercialmente aceitáveis ​​para evitar perdas e roubos, bem como acesso, divulgação, cópia, uso ou modificação não autorizados.</p>
      <br/>
      <h2>5. Direitos do usuário</h2>
      <p>Você é livre para recusar a nossa solicitação de informações pessoais, entendendo que talvez não possamos fornecer alguns dos serviços desejados.</p>
    `},terms:{title:"Termos de Serviço",description:"Termos e condições de uso da oLoveTools.",content:`
      <h2>1. Termos</h2>
      <p>Ao acessar o site da oLoveTools, você concorda em cumprir estes termos de serviço, todas as leis e regulamentos aplicáveis ​​e concorda que é responsável pelo cumprimento de todas as leis locais aplicáveis. Se você não concordar com algum destes termos, está proibido de usar ou acessar este site.</p>
      <br/>
      <h2>2. Licença de uso</h2>
      <p>É concedida permissão para baixar temporariamente uma cópia dos materiais (informações ou software) no site da oLoveTools apenas para visualização transitória pessoal e não comercial. Esta é a concessão de uma licença, não uma transferência de título.</p>
      <br/>
      <h2>3. Isenção de responsabilidade</h2>
      <p>Os materiais no site da oLoveTools são fornecidos "como estão". A oLoveTools não oferece garantias, expressas ou implícitas, e por meio deste isenta e nega todas as outras garantias, incluindo, sem limitação, garantias implícitas ou condições de comercialização, adequação a um propósito específico ou não violação de propriedade intelectual ou outra violação de direitos.</p>
      <br/>
      <h2>4. Limitações</h2>
      <p>Em nenhum caso a oLoveTools ou seus fornecedores serão responsáveis ​​por quaisquer danos (incluindo, sem limitação, danos por perda de dados ou lucros, ou devido a interrupção de negócios) decorrentes do uso ou da incapacidade de usar os materiais no site da oLoveTools.</p>
      <br/>
      <h2>5. Conteúdo de Terceiros</h2>
      <p>Algumas de nossas ferramentas (ex: Clipy, ClipBolt) interagem com APIs de terceiros (como a Twitch). Ao usar essas ferramentas, você também deve cumprir os respectivos Termos de Serviço dessas plataformas de terceiros. Não hospedamos ou possuímos o conteúdo de mídia recuperado através dessas APIs.</p>
    `},cookies:{title:"Política de Cookies",description:"Informações sobre o nosso uso de cookies e tecnologias de rastreamento.",content:`
      <h2>1. O que são cookies?</h2>
      <p>Os cookies são pequenos arquivos de texto que são armazenados no seu computador ou dispositivo móvel quando você visita um site. Eles são amplamente utilizados para fazer os sites funcionarem, ou funcionarem de forma mais eficiente, bem como para fornecer informações aos proprietários do site.</p>
      <br/>
      <h2>2. Como usamos os cookies</h2>
      <p>Utilizamos cookies para melhorar a sua experiência de navegação, apresentar anúncios ou conteúdos personalizados e analisar o nosso tráfego. Usamos cookies essenciais para lembrar a sua preferência de idioma e outras configurações.</p>
      <br/>
      <h2>3. Cookies do Google AdSense</h2>
      <p>Usamos o Google AdSense para veicular anúncios em nosso site. O uso do cookie DART pelo Google permite que ele veicule anúncios para nossos usuários com base em sua visita ao nosso site e a outros sites na Internet. Os usuários podem desativar o uso do cookie DART visitando a política de privacidade da rede de conteúdo e anúncios do Google.</p>
      <br/>
      <h2>4. Gerenciamento de cookies</h2>
      <p>Você pode configurar seu navegador para recusar todos ou alguns cookies, ou para alertá-lo quando sites configurarem ou acessarem cookies. Se você desativar ou recusar cookies, observe que algumas partes deste site podem ficar inacessíveis ou não funcionar corretamente.</p>
    `},about:{title:"Sobre a oLoveTools",description:"Saiba mais sobre a nossa missão e as ferramentas que oferecemos.",content:`
      <h2>Nossa Missão</h2>
      <p>A oLoveTools é um conjunto abrangente de utilitários online gratuitos e de alta qualidade, projetados para simplificar as tarefas diárias de desenvolvedores, designers, criadores de conteúdo e usuários comuns. Nossa missão é fornecer ferramentas poderosas que sejam rápidas, seguras e acessíveis diretamente do seu navegador, sem a necessidade de instalações ou registros.</p>
      <br/>
      <h2>Nossa Filosofia</h2>
      <p>Acreditamos na privacidade e eficiência. Sempre que possível, nossas ferramentas são projetadas para processar dados localmente em seu dispositivo. Isso significa que seus arquivos, imagens e trechos de código nunca saem do seu computador, garantindo máxima privacidade e desempenho extremamente rápido.</p>
      <br/>
      <h2>As Ferramentas</h2>
      <ul>
        <li><strong>Clipy & ClipBolt:</strong> Descubra, organize e baixe seus clipes da Twitch favoritos facilmente.</li>
        <li><strong>FormatFlow:</strong> Uma ferramenta versátil para formatar e converter vários tipos de código e dados.</li>
        <li><strong>PasteSnap:</strong> Capture e gerencie instantaneamente as imagens da sua área de transferência com alta qualidade.</li>
      </ul>
      <br/>
      <p>Estamos constantemente evoluindo e adicionando novos recursos à nossa plataforma. Obrigado por escolher a oLoveTools!</p>
    `},nav:{home:"Início",privacy:"Privacidade",terms:"Termos",cookies:"Cookies",about:"Sobre"}},a={privacy:{title:"Политика Конфиденциальности",description:"Комплексная политика конфиденциальности для oLoveTools.",content:`
      <h2>1. Введение</h2>
      <p>Ваша конфиденциальность важна для нас. Политика oLoveTools заключается в уважении вашей конфиденциальности в отношении любой информации, которую мы можем собирать на нашем веб-сайте olovetools.com и других сайтах, которыми мы владеем и управляем.</p>
      <br/>
      <h2>2. Собираемая нами информация</h2>
      <p>Мы запрашиваем личную информацию только тогда, когда она нам действительно нужна для предоставления вам услуг. Мы собираем ее законными способами, с вашего ведома и согласия. Мы также сообщаем вам, почему мы ее собираем и как она будет использоваться.</p>
      <p>Для большинства наших инструментов (таких как Clipy, ClipBolt, FormatFlow и PasteSnap) обработка происходит полностью в вашем браузере. Мы не храним ваши клипы, изображения или форматированный код на наших серверах.</p>
      <br/>
      <h2>3. Сторонние сервисы и реклама</h2>
      <p>Наш веб-сайт использует Google AdSense для показа рекламы. Google использует файлы cookie для показа рекламы на основе предыдущих посещений пользователем нашего веб-сайта или других веб-сайтов. Использование рекламных файлов cookie компанией Google позволяет ей и ее партнерам показывать рекламу нашим пользователям на основе их посещения наших сайтов и/или других сайтов в Интернете.</p>
      <br/>
      <h2>4. Хранение данных</h2>
      <p>Мы храним собранную информацию только до тех пор, пока это необходимо для предоставления вам запрошенной услуги. Мы будем защищать данные, которые мы храним, коммерчески приемлемыми средствами для предотвращения потери и кражи, а также несанкционированного доступа, раскрытия, копирования, использования или изменения.</p>
      <br/>
      <h2>5. Права пользователя</h2>
      <p>Вы вольны отклонить наш запрос на предоставление вашей личной информации, понимая, что мы, возможно, не сможем предоставить вам некоторые из желаемых услуг.</p>
    `},terms:{title:"Условия Использования",description:"Условия использования oLoveTools.",content:`
      <h2>1. Условия</h2>
      <p>Заходя на веб-сайт oLoveTools, вы соглашаетесь соблюдать эти условия обслуживания, все применимые законы и правила, а также соглашаетесь нести ответственность за соблюдение любых применимых местных законов. Если вы не согласны с каким-либо из этих условий, вам запрещено использовать или посещать этот сайт.</p>
      <br/>
      <h2>2. Лицензия на использование</h2>
      <p>Предоставляется разрешение на временную загрузку одной копии материалов (информации или программного обеспечения) на веб-сайте oLoveTools только для личного некоммерческого временного просмотра. Это предоставление лицензии, а не передача права собственности.</p>
      <br/>
      <h2>3. Отказ от ответственности</h2>
      <p>Материалы на веб-сайте oLoveTools предоставляются «как есть». oLoveTools не дает никаких гарантий, явных или подразумеваемых, и настоящим отказывается от всех других гарантий, включая, помимо прочего, подразумеваемые гарантии или условия товарной пригодности, пригодности для определенной цели или ненарушения прав интеллектуальной собственности или иного нарушения прав.</p>
      <br/>
      <h2>4. Ограничения</h2>
      <p>Ни при каких обстоятельствах oLoveTools или ее поставщики не несут ответственности за любой ущерб (включая, помимо прочего, ущерб от потери данных или прибыли, или из-за прерывания бизнеса), возникший в результате использования или невозможности использования материалов на веб-сайте oLoveTools.</p>
      <br/>
      <h2>5. Сторонний контент</h2>
      <p>Некоторые из наших инструментов (например, Clipy, ClipBolt) взаимодействуют со сторонними API (например, Twitch). Используя эти инструменты, вы также должны соблюдать соответствующие Условия обслуживания этих сторонних платформ. Мы не размещаем и не владеем медиаконтентом, полученным через эти API.</p>
    `},cookies:{title:"Политика Cookie",description:"Информация о нашем использовании файлов cookie и технологий отслеживания.",content:`
      <h2>1. Что такое файлы cookie?</h2>
      <p>Файлы cookie — это небольшие текстовые файлы, которые сохраняются на вашем компьютере или мобильном устройстве при посещении веб-сайта. Они широко используются для того, чтобы веб-сайты работали или работали более эффективно, а также для предоставления информации владельцам сайта.</p>
      <br/>
      <h2>2. Как мы используем файлы cookie</h2>
      <p>Мы используем файлы cookie для улучшения вашего опыта просмотра, показа персонализированной рекламы или контента, а также для анализа нашего трафика. Мы используем основные файлы cookie для запоминания ваших языковых предпочтений и других настроек.</p>
      <br/>
      <h2>3. Файлы cookie Google AdSense</h2>
      <p>Мы используем Google AdSense для показа рекламы на нашем сайте. Использование файлов cookie DART позволяет Google показывать рекламу нашим пользователям на основе их посещений нашего сайта и других сайтов в Интернете. Пользователи могут отказаться от использования файлов cookie DART, посетив политику конфиденциальности рекламной сети Google.</p>
      <br/>
      <h2>4. Управление файлами cookie</h2>
      <p>Вы можете настроить свой браузер так, чтобы он отказывался от всех или некоторых файлов cookie или предупреждал вас, когда веб-сайты устанавливают или получают к ним доступ. Если вы отключите или откажетесь от файлов cookie, обратите внимание, что некоторые части этого веб-сайта могут стать недоступными или не работать должным образом.</p>
    `},about:{title:"Об oLoveTools",description:"Узнайте больше о нашей миссии и предлагаемых нами инструментах.",content:`
      <h2>Наша Миссия</h2>
      <p>oLoveTools — это комплексный набор бесплатных высококачественных онлайн-утилит, разработанных для упрощения повседневных задач разработчиков, дизайнеров, создателей контента и обычных пользователей. Наша миссия — предоставить мощные инструменты, которые работают быстро, безопасно и доступны прямо из вашего браузера без необходимости установки или регистрации.</p>
      <br/>
      <h2>Наша Философия</h2>
      <p>Мы верим в конфиденциальность и эффективность. По возможности наши инструменты предназначены для локальной обработки данных на вашем устройстве. Это означает, что ваши файлы, изображения и фрагменты кода никогда не покидают ваш компьютер, обеспечивая максимальную конфиденциальность и молниеносную производительность.</p>
      <br/>
      <h2>Инструменты</h2>
      <ul>
        <li><strong>Clipy & ClipBolt:</strong> Легко находите, систематизируйте и загружайте свои любимые клипы Twitch.</li>
        <li><strong>FormatFlow:</strong> Универсальный инструмент для форматирования и преобразования различных типов кода и данных.</li>
        <li><strong>PasteSnap:</strong> Мгновенно захватывайте изображения из буфера обмена и управляйте ими с высоким качеством.</li>
      </ul>
      <br/>
      <p>Мы постоянно развиваемся и добавляем новые функции на нашу платформу. Спасибо, что выбрали oLoveTools!</p>
    `},nav:{home:"Главная",privacy:"Конфиденциальность",terms:"Условия",cookies:"Cookies",about:"О нас"}},l={privacy:{title:"गोपनीयता नीति",description:"oLoveTools के लिए व्यापक गोपनीयता नीति।",content:`
      <h2>1. परिचय</h2>
      <p>आपकी गोपनीयता हमारे लिए महत्वपूर्ण है। हमारी वेबसाइट olovetools.com और हमारे द्वारा संचालित अन्य साइटों पर आपके द्वारा एकत्र की जा सकने वाली किसी भी जानकारी के संबंध में आपकी गोपनीयता का सम्मान करना oLoveTools की नीति है।</p>
      <br/>
      <h2>2. जानकारी जो हम एकत्र करते हैं</h2>
      <p>हम केवल व्यक्तिगत जानकारी तभी मांगते हैं जब हमें वास्तव में आपको सेवा प्रदान करने के लिए इसकी आवश्यकता होती है। हम इसे आपके ज्ञान और सहमति के साथ उचित और कानूनी तरीकों से एकत्र करते हैं। हम आपको यह भी बताते हैं कि हम इसे क्यों एकत्र कर रहे हैं और इसका उपयोग कैसे किया जाएगा।</p>
      <p>हमारे अधिकांश उपकरणों (जैसे Clipy, ClipBolt, FormatFlow और PasteSnap) के लिए, प्रसंस्करण पूरी तरह से आपके ब्राउज़र में होता है। हम आपके क्लिप, चित्र या स्वरूपित कोड हमारे सर्वर पर संग्रहीत नहीं करते हैं।</p>
      <br/>
      <h2>3. तृतीय-पक्ष सेवाएँ और विज्ञापन</h2>
      <p>हमारी वेबसाइट विज्ञापन दिखाने के लिए Google AdSense का उपयोग करती है। Google हमारी वेबसाइट या अन्य वेबसाइटों पर उपयोगकर्ता की पूर्व विज़िट के आधार पर विज्ञापन दिखाने के लिए कुकीज़ का उपयोग करता है। Google द्वारा विज्ञापन कुकीज़ का उपयोग उसे और उसके भागीदारों को हमारे उपयोगकर्ताओं को हमारी साइटों और/या इंटरनेट पर अन्य साइटों पर उनके जाने के आधार पर विज्ञापन दिखाने में सक्षम बनाता है।</p>
      <br/>
      <h2>4. डेटा प्रतिधारण</h2>
      <p>हम एकत्र की गई जानकारी को केवल तब तक बनाए रखते हैं जब तक आपको आपकी अनुरोधित सेवा प्रदान करने के लिए आवश्यक हो। जो डेटा हम संग्रहीत करते हैं, उसे नुकसान और चोरी से बचाने के साथ-साथ अनधिकृत पहुंच, प्रकटीकरण, प्रतिलिपि बनाने, उपयोग करने या संशोधन से बचाने के लिए व्यावसायिक रूप से स्वीकार्य तरीकों से सुरक्षित किया जाएगा।</p>
      <br/>
      <h2>5. उपयोगकर्ता के अधिकार</h2>
      <p>आप अपनी व्यक्तिगत जानकारी के लिए हमारे अनुरोध को अस्वीकार करने के लिए स्वतंत्र हैं, इस समझ के साथ कि हम आपको आपकी कुछ वांछित सेवाएँ प्रदान करने में असमर्थ हो सकते हैं।</p>
    `},terms:{title:"सेवा की शर्तें",description:"oLoveTools का उपयोग करने के लिए नियम और शर्तें।",content:`
      <h2>1. शर्तें</h2>
      <p>oLoveTools वेबसाइट तक पहुँचकर, आप इन सेवा की शर्तों, सभी लागू कानूनों और नियमों से बंधे होने के लिए सहमत हैं, और सहमत हैं कि आप किसी भी लागू स्थानीय कानूनों के अनुपालन के लिए जिम्मेदार हैं। यदि आप इन शर्तों में से किसी से सहमत नहीं हैं, तो आपको इस साइट का उपयोग करने या उस तक पहुंचने से प्रतिबंधित कर दिया गया है।</p>
      <br/>
      <h2>2. लाइसेंस का उपयोग करें</h2>
      <p>oLoveTools की वेबसाइट पर सामग्री (जानकारी या सॉफ़्टवेयर) की एक प्रति केवल व्यक्तिगत, गैर-वाणिज्यिक अस्थायी देखने के लिए अस्थायी रूप से डाउनलोड करने की अनुमति दी गई है। यह लाइसेंस का अनुदान है, शीर्षक का हस्तांतरण नहीं।</p>
      <br/>
      <h2>3. अस्वीकरण</h2>
      <p>oLoveTools की वेबसाइट पर सामग्री 'जैसी है' के आधार पर प्रदान की जाती है। oLoveTools कोई वारंटी नहीं देता है, व्यक्त या निहित, और इसके द्वारा अन्य सभी वारंटी को अस्वीकार और नकारता है, जिसमें बिना किसी सीमा के, निहित वारंटी या व्यापारिकता की शर्तें, किसी विशेष उद्देश्य के लिए उपयुक्तता, या बौद्धिक संपदा का गैर-उल्लंघन या अधिकारों का अन्य उल्लंघन शामिल है।</p>
      <br/>
      <h2>4. सीमाएँ</h2>
      <p>किसी भी स्थिति में oLoveTools या उसके आपूर्तिकर्ता oLoveTools की वेबसाइट पर सामग्री का उपयोग करने या उपयोग करने में असमर्थता से उत्पन्न होने वाले किसी भी नुकसान (जिसमें बिना किसी सीमा के, डेटा या लाभ के नुकसान, या व्यावसायिक रुकावट के कारण होने वाले नुकसान शामिल हैं) के लिए उत्तरदायी नहीं होंगे।</p>
      <br/>
      <h2>5. तृतीय-पक्ष सामग्री</h2>
      <p>हमारे कुछ उपकरण (उदा. Clipy, ClipBolt) तृतीय-पक्ष API (जैसे Twitch) के साथ इंटरैक्ट करते हैं। इन उपकरणों का उपयोग करके, आपको उन तृतीय-पक्ष प्लेटफार्मों की संबंधित सेवा की शर्तों का भी पालन करना होगा। हम इन API के माध्यम से प्राप्त मीडिया सामग्री को होस्ट या स्वामित्व नहीं रखते हैं।</p>
    `},cookies:{title:"कुकीज़ नीति",description:"कुकीज़ और ट्रैकिंग प्रौद्योगिकियों के हमारे उपयोग के बारे में जानकारी।",content:`
      <h2>1. कुकीज़ क्या हैं?</h2>
      <p>कुकीज़ छोटी टेक्स्ट फ़ाइलें होती हैं जो वेबसाइट पर जाने पर आपके कंप्यूटर या मोबाइल डिवाइस पर संग्रहीत होती हैं। इनका व्यापक रूप से वेबसाइटों को काम करने, या अधिक कुशलता से काम करने के साथ-साथ साइट के मालिकों को जानकारी प्रदान करने के लिए उपयोग किया जाता है।</p>
      <br/>
      <h2>2. हम कुकीज़ का उपयोग कैसे करते हैं</h2>
      <p>हम आपके ब्राउज़िंग अनुभव को बेहतर बनाने, वैयक्तिकृत विज्ञापन या सामग्री प्रदान करने और हमारे ट्रैफ़िक का विश्लेषण करने के लिए कुकीज़ का उपयोग करते हैं। हम आपकी भाषा वरीयता और अन्य सेटिंग्स को याद रखने के लिए आवश्यक कुकीज़ का उपयोग करते हैं।</p>
      <br/>
      <h2>3. Google AdSense कुकीज़</h2>
      <p>हम अपनी साइट पर विज्ञापन दिखाने के लिए Google AdSense का उपयोग करते हैं। Google का DART कुकी का उपयोग उसे हमारे उपयोगकर्ताओं को हमारी साइट और इंटरनेट पर अन्य साइटों पर उनके जाने के आधार पर विज्ञापन दिखाने में सक्षम बनाता है। उपयोगकर्ता Google विज्ञापन और सामग्री नेटवर्क गोपनीयता नीति पर जाकर DART कुकी के उपयोग का विकल्प चुन सकते हैं।</p>
      <br/>
      <h2>4. कुकीज़ प्रबंधित करना</h2>
      <p>आप अपने ब्राउज़र को सभी या कुछ ब्राउज़र कुकीज़ को अस्वीकार करने या वेबसाइटों द्वारा कुकीज़ सेट करने या उन तक पहुंचने पर आपको सचेत करने के लिए सेट कर सकते हैं। यदि आप कुकीज़ को अक्षम या अस्वीकार करते हैं, तो कृपया ध्यान दें कि इस वेबसाइट के कुछ हिस्से दुर्गम हो सकते हैं या ठीक से काम नहीं कर सकते हैं।</p>
    `},about:{title:"oLoveTools के बारे में",description:"हमारे मिशन और हमारे द्वारा प्रदान किए जाने वाले उपकरणों के बारे में और जानें।",content:`
      <h2>हमारा मिशन</h2>
      <p>oLoveTools डेवलपर्स, डिजाइनरों, सामग्री निर्माताओं और रोजमर्रा के उपयोगकर्ताओं के दैनिक कार्यों को आसान बनाने के लिए डिज़ाइन किए गए मुफ्त, उच्च-गुणवत्ता वाले ऑनलाइन उपयोगिताओं का एक व्यापक सूट है। हमारा मिशन शक्तिशाली उपकरण प्रदान करना है जो तेज़, सुरक्षित और इंस्टॉलेशन या पंजीकरण की आवश्यकता के बिना सीधे आपके ब्राउज़र से सुलभ हों।</p>
      <br/>
      <h2>हमारी फिलॉसफी</h2>
      <p>हम गोपनीयता और दक्षता में विश्वास करते हैं। जब भी संभव हो, हमारे उपकरणों को आपके डिवाइस पर स्थानीय रूप से डेटा संसाधित करने के लिए डिज़ाइन किया गया है। इसका मतलब है कि आपकी फाइलें, चित्र और कोड स्निपेट कभी भी आपके कंप्यूटर को नहीं छोड़ते हैं, जिससे अधिकतम गोपनीयता और तेज प्रदर्शन सुनिश्चित होता है।</p>
      <br/>
      <h2>उपकरण</h2>
      <ul>
        <li><strong>Clipy और ClipBolt:</strong> आसानी से अपने पसंदीदा ट्विच क्लिप खोजें, व्यवस्थित करें और डाउनलोड करें।</li>
        <li><strong>FormatFlow:</strong> विभिन्न प्रकार के कोड और डेटा को स्वरूपित और परिवर्तित करने के लिए एक बहुमुखी उपकरण।</li>
        <li><strong>PasteSnap:</strong> उच्च गुणवत्ता के साथ अपने क्लिपबोर्ड छवियों को तुरंत कैप्चर और प्रबंधित करें।</li>
      </ul>
      <br/>
      <p>हम लगातार विकसित हो रहे हैं और हमारे प्लेटफॉर्म में नई सुविधाएँ जोड़ रहे हैं। oLoveTools चुनने के लिए धन्यवाद!</p>
    `},nav:{home:"होम",privacy:"गोपनीयता",terms:"शर्तें",cookies:"कुकीज़",about:"हमारे बारे में"}},u={privacy:{title:"プライバシーポリシー",description:"oLoveToolsの包括的なプライバシーポリシー。",content:`
      <h2>1. はじめに</h2>
      <p>お客様のプライバシーは私たちにとって重要です。当社のウェブサイトolovetools.com、および当社が所有および運営するその他のサイト全体でお客様から収集する可能性のある情報に関して、お客様のプライバシーを尊重することがoLoveToolsのポリシーです。</p>
      <br/>
      <h2>2. 収集する情報</h2>
      <p>私たちは、サービスを提供するために本当に必要な場合にのみ個人情報を要求します。私たちは、お客様の知識と同意を得て、公正かつ合法的な手段でそれを収集します。また、収集する理由とその使用方法についてもお知らせします。</p>
      <p>ほとんどのツール（Clipy、ClipBolt、FormatFlow、PasteSnapなど）では、処理は完全にブラウザ内で行われます。お客様のクリップ、画像、またはフォーマットされたコードを当社のサーバーに保存することはありません。</p>
      <br/>
      <h2>3. サードパーティのサービスと広告</h2>
      <p>当社のウェブサイトは、広告を配信するためにGoogle AdSenseを使用しています。Googleは、ユーザーが過去に当社のウェブサイトまたは他のウェブサイトにアクセスしたことに基づいて広告を配信するためにCookieを使用します。Googleによる広告Cookieの使用により、Googleとそのパートナーは、当社のサイトやインターネット上の他のサイトへのアクセスに基づいて、ユーザーに広告を配信できます。</p>
      <br/>
      <h2>4. データの保持</h2>
      <p>収集した情報は、要求されたサービスを提供するために必要な期間のみ保持します。私たちが保存するデータは、紛失や盗難、不正アクセス、開示、コピー、使用、変更を防ぐために、商業的に許容される範囲内で保護されます。</p>
      <br/>
      <h2>5. ユーザーの権利</h2>
      <p>お客様は、お客様の個人情報の要求を自由に拒否することができますが、ご希望の一部のサービスを提供できない場合があります。</p>
    `},terms:{title:"利用規約",description:"oLoveToolsを使用するための利用規約。",content:`
      <h2>1. 規約</h2>
      <p>oLoveToolsのウェブサイトにアクセスすることにより、これらの利用規約、および適用されるすべての法律と規制に拘束されることに同意し、適用される現地の法律を遵守する責任があることに同意するものとします。これらの条件のいずれかに同意しない場合は、このサイトの使用またはアクセスを禁止します。</p>
      <br/>
      <h2>2. 利用ライセンス</h2>
      <p>個人的、非営利的な一時的な閲覧のみを目的として、oLoveToolsのウェブサイト上の資料（情報またはソフトウェア）の1つのコピーを一時的にダウンロードする許可が与えられます。これはライセンスの付与であり、所有権の譲渡ではありません。</p>
      <br/>
      <h2>3. 免責事項</h2>
      <p>oLoveToolsのウェブサイト上の資料は「現状有姿」で提供されます。oLoveToolsは、明示または黙示を問わず、いかなる保証も行わず、商品性、特定の目的への適合性、または知的財産の非侵害またはその他の権利の侵害の黙示の保証または条件を含むがこれらに限定されない、その他のすべての保証をここに否認および無効にします。</p>
      <br/>
      <h2>4. 制限事項</h2>
      <p>oLoveToolsまたはそのサプライヤーは、oLoveToolsのウェブサイト上の資料の使用または使用不能から生じるいかなる損害（データまたは利益の損失、または事業の中断による損害を含むがこれらに限定されない）についても責任を負わないものとします。</p>
      <br/>
      <h2>5. サードパーティコンテンツ</h2>
      <p>当社のツールの一部（Clipy、ClipBoltなど）は、サードパーティのAPI（Twitchなど）と対話します。これらのツールを使用することにより、それらのサードパーティプラットフォームのそれぞれの利用規約にも従う必要があります。当社は、これらのAPIを通じて取得されたメディアコンテンツをホストまたは所有していません。</p>
    `},cookies:{title:"クッキーポリシー",description:"クッキーおよび追跡テクノロジーの使用に関する情報。",content:`
      <h2>1. クッキーとは？</h2>
      <p>クッキーは、ウェブサイトにアクセスしたときにコンピューターまたはモバイルデバイスに保存される小さなテキストファイルです。これらは、ウェブサイトを機能させるため、またはより効率的に機能させるため、およびサイトの所有者に情報を提供するために広く使用されています。</p>
      <br/>
      <h2>2. クッキーの使用方法</h2>
      <p>ブラウジングエクスペリエンスを向上させ、パーソナライズされた広告やコンテンツを提供し、トラフィックを分析するためにクッキーを使用します。言語設定やその他の設定を記憶するために不可欠なクッキーを使用します。</p>
      <br/>
      <h2>3. Google AdSenseクッキー</h2>
      <p>当サイトに広告を配信するためにGoogle AdSenseを使用しています。GoogleがDARTクッキーを使用することで、当サイトやインターネット上の他のサイトへのアクセスに基づいてユーザーに広告を配信できます。ユーザーは、Googleの広告およびコンテンツネットワークのプライバシーポリシーにアクセスして、DARTクッキーの使用をオプトアウトできます。</p>
      <br/>
      <h2>4. クッキーの管理</h2>
      <p>ブラウザのクッキーのすべてまたは一部を拒否したり、ウェブサイトがクッキーを設定またはアクセスしたときに警告するようにブラウザを設定したりできます。クッキーを無効または拒否した場合、このウェブサイトの一部にアクセスできなくなったり、正しく機能しなくなったりする可能性があることに注意してください。</p>
    `},about:{title:"oLoveToolsについて",description:"私たちの使命と私たちが提供するツールについて。",content:`
      <h2>私たちの使命</h2>
      <p>oLoveToolsは、開発者、デザイナー、コンテンツクリエーター、日常のユーザーの日常的なタスクを簡素化するように設計された、無料で高品質なオンラインユーティリティの包括的なスイートです。私たちの使命は、インストールや登録を必要とせずに、ブラウザから直接アクセスできる、高速で安全な強力なツールを提供することです。</p>
      <br/>
      <h2>私たちの哲学</h2>
      <p>私たちはプライバシーと効率を信じています。可能な限り、私たちのツールはデバイス上でローカルにデータを処理するように設計されています。これは、ファイル、画像、およびコードスニペットがコンピューターから離れることはなく、最大限のプライバシーと超高速のパフォーマンスを保証することを意味します。</p>
      <br/>
      <h2>ツール</h2>
      <ul>
        <li><strong>Clipy & ClipBolt:</strong> お気に入りのTwitchクリップを簡単に見つけ、整理し、ダウンロードします。</li>
        <li><strong>FormatFlow:</strong> さまざまな種類のコードとデータをフォーマットおよび変換するための多目的ツール。</li>
        <li><strong>PasteSnap:</strong> クリップボードの画像を高品質ですばやくキャプチャして管理します。</li>
      </ul>
      <br/>
      <p>私たちは常に進化しており、プラットフォームに新機能を追加しています。oLoveToolsをお選びいただきありがとうございます！</p>
    `},nav:{home:"ホーム",privacy:"プライバシー",terms:"利用規約",cookies:"クッキー",about:"概要"}},c={privacy:{title:"隐私政策",description:"oLoveTools的全面隐私政策。",content:`
      <h2>1. 简介</h2>
      <p>您的隐私对我们很重要。oLoveTools的政策是尊重您在访问我们的网站olovetools.com以及我们拥有和运营的其他网站时，我们可能从您那里收集的任何信息的隐私。</p>
      <br/>
      <h2>2. 我们收集的信息</h2>
      <p>我们仅在真正需要时才要求提供个人信息以向您提供服务。我们在您知情并同意的情况下，通过公平合法的方式收集它。我们还会让您知道我们收集它的原因以及将如何使用它。</p>
      <p>对于我们的大多数工具（例如Clipy，ClipBolt，FormatFlow和PasteSnap），处理完全在您的浏览器中进行。我们不会将您的剪辑、图像或格式化的代码存储在我们的服务器上。</p>
      <br/>
      <h2>3. 第三方服务和广告</h2>
      <p>我们的网站使用Google AdSense来投放广告。Google使用cookie来根据用户以前对我们网站或其他网站的访问来投放广告。Google使用广告cookie使其及其合作伙伴能够根据用户对我们网站和/或互联网上其他网站的访问向其投放广告。</p>
      <br/>
      <h2>4. 数据保留</h2>
      <p>我们仅在为您提供所需服务所需的时间内保留收集的信息。我们将通过商业上可接受的方法保护我们存储的数据，以防止丢失和盗窃，以及未经授权的访问、披露、复制、使用或修改。</p>
      <br/>
      <h2>5. 用户权利</h2>
      <p>您可以自由拒绝我们对您个人信息的请求，但请理解，我们可能无法为您提供某些所需的服务。</p>
    `},terms:{title:"服务条款",description:"使用oLoveTools的条款和条件。",content:`
      <h2>1. 条款</h2>
      <p>通过访问oLoveTools网站，您同意受这些服务条款以及所有适用的法律法规的约束，并同意您有责任遵守任何适用的当地法律。如果您不同意这些条款的任何内容，则禁止您使用或访问本网站。</p>
      <br/>
      <h2>2. 使用许可</h2>
      <p>允许临时下载oLoveTools网站上材料（信息或软件）的副本，仅供个人和非商业性临时查看。这是许可的授予，而不是所有权的转让。</p>
      <br/>
      <h2>3. 免责声明</h2>
      <p>oLoveTools网站上的材料按“原样”提供。oLoveTools不作任何明示或暗示的保证，特此声明并否认所有其他保证，包括但不限于适销性、特定用途的适用性或不侵犯知识产权或其他侵权的暗示保证或条件。</p>
      <br/>
      <h2>4. 限制</h2>
      <p>在任何情况下，oLoveTools或其供应商均不对因使用或无法使用oLoveTools网站上的材料而引起的任何损害（包括但不限于数据或利润损失，或因业务中断造成的损害）负责。</p>
      <br/>
      <h2>5. 第三方内容</h2>
      <p>我们的一些工具（例如Clipy，ClipBolt）与第三方API（如Twitch）交互。通过使用这些工具，您还必须遵守这些第三方平台的相应服务条款。我们不托管或拥有通过这些API检索的媒体内容。</p>
    `},cookies:{title:"Cookie政策",description:"有关我们使用cookie和跟踪技术的信息。",content:`
      <h2>1. 什么是cookie？</h2>
      <p>Cookie是您访问网站时存储在计算机或移动设备上的小文本文件。它们被广泛用于使网站工作或更有效地工作，以及为网站所有者提供信息。</p>
      <br/>
      <h2>2. 我们如何使用cookie</h2>
      <p>我们使用cookie来改善您的浏览体验，投放个性化广告或内容，并分析我们的流量。我们使用必要的cookie来记住您的语言偏好和其他设置。</p>
      <br/>
      <h2>3. Google AdSense Cookie</h2>
      <p>我们在网站上使用Google AdSense来投放广告。Google使用DART cookie使其能够根据用户对我们网站以及互联网上其他网站的访问向其投放广告。用户可以通过访问Google广告和内容网络隐私政策来选择退出使用DART cookie。</p>
      <br/>
      <h2>4. 管理cookie</h2>
      <p>您可以将浏览器设置为拒绝所有或部分浏览器cookie，或在网站设置或访问cookie时提醒您。如果您禁用或拒绝cookie，请注意，本网站的某些部分可能无法访问或无法正常工作。</p>
    `},about:{title:"关于oLoveTools",description:"了解有关我们的使命和我们提供的工具的更多信息。",content:`
      <h2>我们的使命</h2>
      <p>oLoveTools是一个全面、免费、高质量的在线实用程序套件，旨在简化开发人员、设计师、内容创作者和日常用户的日常任务。我们的使命是提供功能强大、快速、安全且可以直接从浏览器访问的工具，而无需安装或注册。</p>
      <br/>
      <h2>我们的理念</h2>
      <p>我们相信隐私和效率。只要有可能，我们的工具旨在在您的设备上本地处理数据。这意味着您的文件、图像和代码片段永远不会离开您的计算机，从而确保最大的隐私和极快的性能。</p>
      <br/>
      <h2>工具</h2>
      <ul>
        <li><strong>Clipy & ClipBolt：</strong>轻松发现、组织和下载您喜欢的Twitch剪辑。</li>
        <li><strong>FormatFlow：</strong>一个多功能的工具，用于格式化和转换各种类型的代码和数据。</li>
        <li><strong>PasteSnap：</strong>高质量、即时地捕获和管理您的剪贴板图像。</li>
      </ul>
      <br/>
      <p>我们正在不断发展，并向我们的平台添加新功能。感谢您选择oLoveTools！</p>
    `},nav:{home:"首页",privacy:"隐私",terms:"条款",cookies:"Cookies",about:"关于"}},h={en:s,es:i,fr:n,de:r,pt:t,ru:a,hi:l,ja:u,zh:c};export{p as C,h as l};
