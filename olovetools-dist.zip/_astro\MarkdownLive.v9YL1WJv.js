import{c as T,j as e}from"./createLucideIcon.D7mwnnQi.js";import{r as u}from"./index.WUCsyqyj.js";import{L as z}from"./constants.XumZoD8a.js";import{C as se,l as j}from"./index.CHbPCdf3.js";import{F as ne}from"./file-text.BXj3s4ud.js";import{A as K}from"./AdBanner.yEYg3BeB.js";import{S as ie}from"./sparkles.gF7OamGa.js";import{L as ae}from"./link.DdiC4eMC.js";import{I as ce}from"./image.C4iG50Dv.js";import{C as de}from"./code.Bvlh-xPF.js";import{L as me}from"./list.CCpOayWS.js";import{L as he}from"./list-ordered.mogi-j1p.js";import{M as pe}from"./minus.CIoodIV3.js";import{S as xe}from"./settings.CwCFkoCd.js";import{E as be}from"./eye.i0ltUlJj.js";import{F as J}from"./file-code.CmOU1rQg.js";import{D as ue}from"./download.DDQL_3OR.js";import{C as fe}from"./copy.Cu1_tk6q.js";const we=[["path",{d:"M6 12h9a4 4 0 0 1 0 8H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h7a4 4 0 0 1 0 8",key:"mg9rjx"}]],ge=T("bold",we);const ve=[["path",{d:"M6 12h12",key:"8npq4p"}],["path",{d:"M6 20V4",key:"1w1bmo"}],["path",{d:"M18 20V4",key:"o2hl4u"}]],ye=T("heading",ve);const je=[["line",{x1:"19",x2:"10",y1:"4",y2:"4",key:"15jd3p"}],["line",{x1:"14",x2:"5",y1:"20",y2:"20",key:"bu0au3"}],["line",{x1:"15",x2:"9",y1:"4",y2:"20",key:"uljnxc"}]],ke=T("italic",je);const Ne=[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]],Ce=T("printer",Ne);const _e=[["path",{d:"M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",key:"rib7q0"}],["path",{d:"M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",key:"1ymkrd"}]],Te=T("quote",_e);const $e=[["path",{d:"M12 3v18",key:"108xh3"}],["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M3 9h18",key:"1pudct"}],["path",{d:"M3 15h18",key:"5xshup"}]],Le=T("table",$e);const Me=[["path",{d:"M12 19h8",key:"baeox8"}],["path",{d:"m4 17 6-6-6-6",key:"1yngyt"}]],Se=T("terminal",Me),Ee=({currentLang:i,onLanguageChange:s})=>{const[o,c]=u.useState(!1),h=u.useRef(null);u.useEffect(()=>{const p=f=>{h.current&&!h.current.contains(f.target)&&c(!1)};return document.addEventListener("mousedown",p),()=>document.removeEventListener("mousedown",p)},[]);const y=z.find(p=>p.code===i)||z[0];return e.jsxs("div",{className:"relative w-full flex justify-center",ref:h,children:[e.jsxs("button",{onClick:()=>c(!o),className:"flex items-center justify-between md:justify-center w-[70%] md:w-12 h-12 md:p-0 px-8 rounded-full border border-gray-700 bg-gray-900/50 hover:bg-gray-800 transition-colors text-xs md:text-sm font-black text-gray-300 uppercase cursor-pointer shadow-lg outline-none",children:[e.jsx("span",{className:"md:hidden",children:y.name}),e.jsx("span",{className:"hidden md:block",children:y.code}),e.jsx(se,{className:`w-4 h-4 ml-2 transition-transform md:hidden ${o?"rotate-180":""}`})]}),o&&e.jsx("div",{className:"absolute left-1/2 -translate-x-1/2 md:left-auto md:translate-x-0 md:right-0 mt-12 w-48 bg-[#030208] border border-violet-950 rounded-lg shadow-2xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200",children:e.jsx("div",{className:"py-1",children:z.map(p=>e.jsxs("button",{onClick:()=>{s(p.code),c(!1)},className:`w-full flex items-center px-4 py-3 text-sm hover:bg-violet-950/30 transition-colors cursor-pointer text-left ${i===p.code?"bg-violet-950/60 text-white":"text-gray-300"}`,children:[e.jsx("span",{className:"font-bold mr-3 w-6 uppercase text-violet-400",children:p.code}),e.jsx("span",{children:p.name})]},p.code))})})]})},He=()=>e.jsx("svg",{className:"w-7 h-7 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{d:"M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"})}),Be=({currentLang:i,onLanguageChange:s,onReset:o,t:c})=>e.jsx("div",{className:"fixed top-0 left-0 right-0 z-[100] pointer-events-none",children:e.jsx("header",{className:"w-full h-auto md:h-24 py-4 md:py-0 border-b border-white/10 bg-[#030208]/95 backdrop-blur-3xl shadow-[0_10px_40px_rgba(0,0,0,0.5)] pointer-events-auto",children:e.jsxs("div",{className:"max-w-7xl mx-auto h-full px-4 md:px-12 flex flex-col md:flex-row items-center justify-between gap-4 md:gap-0",children:[e.jsxs("div",{className:"flex items-center justify-between w-full md:w-auto space-x-4 md:space-x-12",children:[e.jsxs("a",{href:`/${i.toLowerCase()}`,className:"flex items-center space-x-2 md:space-x-3 group outline-none shrink-0",children:[e.jsx("div",{className:"w-9 h-9 md:w-11 md:h-11 bg-red-600 rounded-xl md:rounded-2xl flex items-center justify-center group-hover:bg-red-500 transition-all group-hover:rotate-6 group-hover:scale-110 shadow-lg shadow-red-600/40",children:e.jsx(He,{})}),e.jsxs("div",{className:"text-2xl md:text-3xl font-black tracking-tighter transition-all group-hover:scale-105",children:[e.jsx("span",{className:"text-white",children:"oLove"}),e.jsx("span",{className:"text-red-400",children:"Tools"})]})]}),e.jsx("div",{className:"h-8 w-px bg-white/10 hidden sm:block"}),e.jsxs("button",{onClick:o,className:"flex items-center space-x-2 md:space-x-3 group border-none bg-transparent outline-none transition-all hover:translate-x-1 cursor-pointer",children:[e.jsx("div",{className:"w-8 h-8 md:w-9 md:h-9 bg-white/5 rounded-lg md:rounded-xl flex items-center justify-center border border-white/10 group-hover:bg-violet-500/20 group-hover:border-violet-500/50 transition-all",children:e.jsx(ne,{className:"w-5 h-5 text-violet-500"})}),e.jsx("span",{className:"text-xl md:text-2xl font-black text-white tracking-tight group-hover:text-violet-500 transition-all",children:c.title})]})]}),e.jsx("div",{className:"flex items-center justify-center w-full md:w-auto",children:e.jsx(Ee,{currentLang:i,onLanguageChange:s})})]})})}),Re=({lang:i,t:s,onOpenModal:o})=>e.jsx("footer",{className:"py-24 md:py-36 border-t border-white/5 flex flex-col items-center space-y-16 relative z-10 bg-[#030208] w-full",children:e.jsxs("div",{className:"flex flex-col items-center space-y-16 max-w-5xl px-8 text-center",children:[e.jsx("div",{className:"text-gray-600 text-xs font-black tracking-[0.6em] uppercase opacity-40",children:s.footerCredit||"Part of the oLoveTools suite"}),e.jsxs("a",{href:`/${i.toLowerCase()}/`,className:"flex items-center space-x-6 group scale-[1.1] md:scale-[1.5] outline-none shrink-0",children:[e.jsx("div",{className:"w-12 h-12 bg-red-600 rounded-[1.2rem] flex items-center justify-center group-hover:rotate-12 transition-transform shadow-[0_15px_30px_-5px_rgba(239,68,68,0.5)]",children:e.jsx("svg",{className:"w-7 h-7 text-white",fill:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{d:"M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"})})}),e.jsxs("div",{className:"flex items-center space-x-1 font-black text-4xl tracking-tighter",children:[e.jsx("span",{className:"text-white transition-all group-hover:text-red-400",children:"oLove"}),e.jsx("span",{className:"text-red-400 group-hover:translate-x-1 group-hover:text-white transition-all",children:"Tools"})]})]}),e.jsx("p",{className:"text-gray-500 text-lg md:text-xl font-medium leading-relaxed max-w-2xl",children:s.footerTagline}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-8 text-left max-w-4xl border-t border-white/5 pt-16 mt-8",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-white font-bold text-lg mb-3",children:s.seoBrowserSpeedTitle}),e.jsx("p",{className:"text-gray-400 text-sm leading-relaxed",children:s.seoBrowserSpeedText})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-white font-bold text-lg mb-3",children:s.seoUseCaseTitle}),e.jsx("p",{className:"text-gray-400 text-sm leading-relaxed",children:s.seoUseCaseText})]}),e.jsxs("div",{className:"md:col-span-2",children:[e.jsx("h3",{className:"text-white font-bold text-lg mb-3",children:s.seoSecondaryTitle||s.seoPrivacyTitle}),e.jsx("p",{className:"text-gray-400 text-sm leading-relaxed mb-4",children:s.seoPrivacyText}),e.jsx("div",{className:"flex flex-wrap gap-2 pt-2",children:Array.isArray(s.seoKeywords)&&s.seoKeywords.map(c=>e.jsx("span",{className:"text-[10px] text-gray-500 bg-white/5 border border-white/10 px-2 py-1 rounded",children:c},c))})]})]}),Array.isArray(s.faq)&&s.faq.length>0&&e.jsxs("div",{className:"w-full text-left max-w-4xl border-t border-white/5 pt-16",children:[e.jsx("h2",{className:"text-white font-black text-2xl mb-8 tracking-tight text-center",children:s.faqTitle}),e.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-8",children:s.faq.map((c,h)=>e.jsxs("div",{className:"bg-white/[0.02] border border-white/5 p-6 rounded-2xl hover:border-violet-500/20 transition-colors",children:[e.jsx("h4",{className:"text-white font-bold text-base mb-2",children:c.question}),e.jsx("p",{className:"text-gray-400 text-sm leading-relaxed",children:c.answer})]},h))})]}),e.jsxs("div",{className:"flex flex-col md:flex-row flex-wrap items-center justify-center gap-y-2 md:gap-y-6 gap-x-4 md:gap-x-8 text-gray-800 font-black text-[11px] md:text-xs tracking-widest pt-12 border-t border-white/5 w-full uppercase",children:[e.jsxs("span",{className:"w-full md:w-auto mb-4 md:mb-0 opacity-40",children:["© ",new Date().getFullYear()," oLoveTools"]}),e.jsx("button",{onClick:()=>o("privacy"),className:"w-full md:w-auto py-3 md:py-0 border-none bg-transparent hover:text-violet-500 active:bg-white/5 active:scale-95 transition-all cursor-pointer whitespace-nowrap rounded-xl text-center font-black outline-none",children:j[i]?.nav.privacy||"Privacy Policy"}),e.jsx("button",{onClick:()=>o("terms"),className:"w-full md:w-auto py-3 md:py-0 border-none bg-transparent hover:text-violet-500 active:bg-white/5 active:scale-95 transition-all cursor-pointer whitespace-nowrap rounded-xl text-center font-black outline-none",children:j[i]?.nav.terms||"Terms of Service"}),e.jsx("button",{onClick:()=>o("cookies"),className:"w-full md:w-auto py-3 md:py-0 border-none bg-transparent hover:text-violet-500 active:bg-white/5 active:scale-95 transition-all cursor-pointer whitespace-nowrap rounded-xl text-center font-black outline-none",children:j[i]?.nav.cookies||"Cookie Policy"}),e.jsx("a",{href:`/${i.toLowerCase()}/about`,className:"w-full md:w-auto py-3 md:py-0 hover:text-violet-500 active:bg-white/5 active:scale-95 transition-all cursor-pointer whitespace-nowrap rounded-xl text-center font-black",children:j[i]?.nav.about||"About"}),e.jsx("button",{onClick:()=>{navigator.clipboard.writeText(s.emailAddress||"adrian.contact.me.69@gmail.com");const c=document.getElementById("copy-email-footer-btn");if(c){const h=c.innerText;c.innerText=s.emailCopied||"Copied!",setTimeout(()=>{c.innerText=h},2e3)}},id:"copy-email-footer-btn",className:"w-full md:w-auto py-3 md:py-0 border-none bg-transparent hover:text-violet-500 active:bg-white/5 active:scale-95 transition-all cursor-pointer rounded-xl font-black outline-none",children:s.emailAddress||"adrian.contact.me.69@gmail.com"})]})]})}),F=({isOpen:i,onClose:s,title:o,content:c,t:h})=>{const y=u.useRef(null);if(u.useEffect(()=>{const f=$=>{y.current&&!y.current.contains($.target)&&s()};return i&&document.addEventListener("mousedown",f),()=>{document.removeEventListener("mousedown",f)}},[i,s]),!i)return null;const p=()=>{navigator.clipboard.writeText(h.emailAddress||"adrian.contact.me.69@gmail.com");const f=document.getElementById("copy-email-modal-btn");if(f){const $=f.innerText;f.innerText=h.emailCopied||"Copied!",setTimeout(()=>{f.innerText=$},2e3)}};return e.jsx("div",{className:"fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200",children:e.jsxs("div",{ref:y,className:"bg-[#030208] border border-white/10 p-8 rounded-3xl shadow-2xl w-full max-w-lg max-h-[80vh] overflow-y-auto animate-in zoom-in-95 duration-200 relative",children:[e.jsx("button",{onClick:s,className:"absolute top-6 right-6 text-gray-400 hover:text-white cursor-pointer border-none bg-transparent outline-none",children:e.jsx("svg",{className:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M6 18L18 6M6 6l12 12"})})}),e.jsx("h2",{className:"text-2xl font-black text-white mb-6",children:o}),e.jsx("div",{className:"text-gray-300 mb-8 space-y-4 whitespace-pre-line text-sm leading-relaxed",children:c}),e.jsxs("div",{className:"border-t border-white/10 pt-6",children:[e.jsx("p",{className:"text-xs font-black text-gray-500 uppercase tracking-widest mb-3",children:h.contactForIdeas||"Contact for ideas and comments:"}),e.jsxs("button",{id:"copy-email-modal-btn",onClick:p,className:"flex items-center space-x-3 text-violet-500 hover:text-violet-400 border-none bg-transparent outline-none transition-colors font-mono cursor-pointer",children:[e.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:e.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2",d:"M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2z"})}),e.jsx("span",{children:h.emailAddress||"adrian.contact.me.69@gmail.com"})]})]})]})})};function st({lang:i,dictionary:s}){const o=s||{},c=o.placeholder||`# Welcome to Markdown-Live!

Type some markdown here on the left to see it rendered instantly on the right.

## Basic Styling

You can make text **bold** or *italic* easily, or embed \`inline code\` or custom links like [oLoveTools](https://olovetools.com).

### Code Block Example

\`\`\`javascript
function greet(name) {
  console.log('Hello, ' + name + '!');
}
greet('World');
\`\`\`

### Blockquotes & Lists

> Markdown is a lightweight markup language with plain-text-formatting syntax.

- Quick markdown editor
- 100% offline client-side parsing
- Responsive split-screen preview

### Tables Support

| Item | Count | Status |
| :--- | :---: | :---: |
| Editor | 1 | Done |
| Previewer | 1 | Live |
`,[h,y]=u.useState(c),[p,f]=u.useState("preview"),[$,Y]=u.useState("slate"),[W,U]=u.useState(!1),[A,B]=u.useState(null),R=u.useRef(null),D=u.useRef(null),k=u.useRef(null);u.useEffect(()=>{o.placeholder&&y(o.placeholder)},[o.placeholder]);const q=(r=>{if(!r)return"";let t=r.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");const d=[];t=t.replace(/```(\w*)\n([\s\S]*?)\n```/g,(l,n,a)=>{const x=`__CODE_BLOCK_${d.length}__`;return d.push(`<pre class="bg-gray-950/90 border border-white/10 p-4 rounded-xl overflow-x-auto my-4 font-mono text-sm text-gray-200"><code class="language-${n}">${a.trim()}</code></pre>`),x});const m=[];t=t.replace(/`([^`]+)`/g,(l,n)=>{const a=`__INLINE_CODE_${m.length}__`;return m.push(`<code class="bg-violet-500/10 border border-violet-500/20 px-1.5 py-0.5 rounded font-mono text-xs text-violet-400 font-semibold">${n}</code>`),a}),t=t.replace(/^---$/gm,'<hr class="my-6 border-t border-white/10" />'),t=t.replace(/^######\s+(.*)$/gm,'<h6 class="text-xs font-bold text-gray-400 mt-6 mb-2 uppercase tracking-wider">$1</h6>'),t=t.replace(/^#####\s+(.*)$/gm,'<h5 class="text-sm font-bold text-gray-300 mt-6 mb-2">$1</h5>'),t=t.replace(/^####\s+(.*)$/gm,'<h4 class="text-base font-bold text-gray-200 mt-6 mb-2">$1</h4>'),t=t.replace(/^###\s+(.*)$/gm,'<h3 class="text-lg font-bold text-white mt-6 mb-3">$1</h3>'),t=t.replace(/^##\s+(.*)$/gm,'<h2 class="text-xl font-extrabold text-white mt-8 mb-4 border-b border-white/5 pb-2">$1</h2>'),t=t.replace(/^#\s+(.*)$/gm,'<h1 class="text-3xl font-black text-white mt-10 mb-6">$1</h1>');const N=t.split(`
`),C=[];let S=!1,_=[];for(let l=0;l<N.length;l++){const n=N[l];n.startsWith("&gt;")?(S=!0,_.push(n.substring(4).trim())):(S&&(C.push(`<blockquote class="border-l-4 border-violet-500 bg-violet-950/20 px-4 py-3 my-4 rounded-r-xl italic text-gray-300">${_.join("<br />")}</blockquote>`),_=[],S=!1),C.push(n))}S&&C.push(`<blockquote class="border-l-4 border-violet-500 bg-violet-950/20 px-4 py-3 my-4 rounded-r-xl italic text-gray-300">${_.join("<br />")}</blockquote>`),t=C.join(`
`);const E=t.split(`
`),L=[];let H=!1,I=[],M=[],P=[];for(let l=0;l<E.length;l++){const n=E[l].trim();if(n.startsWith("|")&&n.endsWith("|")){const a=n.split("|").slice(1,-1).map(x=>x.trim());H?a.every(b=>b.match(/^:?-+:?$/))?M=a.map(b=>b.startsWith(":")&&b.endsWith(":")?"center":b.endsWith(":")?"right":"left"):P.push(a):(H=!0,I=a)}else{if(H){let a='<div class="overflow-x-auto my-6"><table class="w-full text-sm text-left border-collapse border border-white/10 rounded-xl overflow-hidden">';a+='<thead class="bg-white/5 border-b border-white/10 text-white font-bold"><tr>',I.forEach((x,b)=>{const O=M[b]||"left";a+=`<th class="px-4 py-3 text-${O}">${x}</th>`}),a+='</tr></thead><tbody class="divide-y divide-white/5">',P.forEach(x=>{a+='<tr class="hover:bg-white/[0.02] transition-colors">',x.forEach((b,O)=>{const le=M[O]||"left";a+=`<td class="px-4 py-3 text-gray-300 text-${le}">${b}</td>`}),a+="</tr>"}),a+="</tbody></table></div>",L.push(a),H=!1,I=[],M=[],P=[]}L.push(E[l])}}if(H){let l='<div class="overflow-x-auto my-6"><table class="w-full text-sm text-left border-collapse border border-white/10 rounded-xl overflow-hidden">';l+='<thead class="bg-white/5 border-b border-white/10 text-white font-bold"><tr>',I.forEach((n,a)=>{const x=M[a]||"left";l+=`<th class="px-4 py-3 text-${x}">${n}</th>`}),l+='</tr></thead><tbody class="divide-y divide-white/5">',P.forEach(n=>{l+='<tr class="hover:bg-white/[0.02] transition-colors">',n.forEach((a,x)=>{const b=M[x]||"left";l+=`<td class="px-4 py-3 text-gray-300 text-${b}">${a}</td>`}),l+="</tr>"}),l+="</tbody></table></div>",L.push(l)}t=L.join(`
`);const G=t.split(`
`),g=[];let v=null;for(let l=0;l<G.length;l++){const n=G[l],a=n.match(/^(\s*)([*\-+])\s+(.*)$/),x=n.match(/^(\s*)(\d+)\.\s+(.*)$/);if(a){const b=a[3];v!=="ul"&&(v==="ol"&&g.push("</ol>"),g.push('<ul class="list-disc pl-6 my-4 space-y-1.5 text-gray-300">'),v="ul"),g.push(`<li>${b}</li>`)}else if(x){const b=x[3];v!=="ol"&&(v==="ul"&&g.push("</ul>"),g.push('<ol class="list-decimal pl-6 my-4 space-y-1.5 text-gray-300">'),v="ol"),g.push(`<li>${b}</li>`)}else v==="ul"?(g.push("</ul>"),v=null):v==="ol"&&(g.push("</ol>"),v=null),g.push(n)}return v==="ul"?g.push("</ul>"):v==="ol"&&g.push("</ol>"),t=g.join(`
`),t=t.replace(/!\[([^\]]*)\]\(([^)]+)\)/g,'<img src="$2" alt="$1" class="rounded-xl border border-white/10 max-w-full h-auto my-4 shadow-lg" />'),t=t.replace(/\[([^\]]+)\]\(([^)]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer" class="text-violet-400 hover:text-violet-300 underline font-semibold transition-colors">$1</a>'),t=t.replace(/\*\*([^*]+)\*\*/g,"<strong>$1</strong>"),t=t.replace(/__([^_]+)__/g,"<strong>$1</strong>"),t=t.replace(/\*([^*]+)\*/g,"<em>$1</em>"),t=t.replace(/_([^_]+)_/g,"<em>$1</em>"),t=t.replace(/~~([^~]+)~~/g,"<del>$1</del>"),t=t.split(/\n\s*\n/).map(l=>{const n=l.trim();return n?/^(<h[1-6]|<ul|<ol|<table|<div|<pre|<blockquote|<hr|<li)/i.test(n)?n:`<p class="leading-relaxed mb-4 text-gray-300">${n.replace(/\n/g,"<br />")}</p>`:""}).join(`
`),m.forEach((l,n)=>{t=t.replace(`__INLINE_CODE_${n}__`,l)}),d.forEach((l,n)=>{t=t.replace(`__CODE_BLOCK_${n}__`,l)}),t})(h),Q=()=>{if(k.current==="preview")return;k.current="editor";const r=R.current,t=D.current;if(r&&t){const d=r.scrollTop/(r.scrollHeight-r.clientHeight);t.scrollTop=d*(t.scrollHeight-t.clientHeight)}setTimeout(()=>{k.current==="editor"&&(k.current=null)},50)},X=()=>{if(k.current==="editor")return;k.current="preview";const r=R.current,t=D.current;if(r&&t){const d=t.scrollTop/(t.scrollHeight-t.clientHeight);r.scrollTop=d*(r.scrollHeight-r.clientHeight)}setTimeout(()=>{k.current==="preview"&&(k.current=null)},50)},w=(r,t="",d="")=>{const m=R.current;if(!m)return;const N=m.selectionStart,C=m.selectionEnd,_=m.value.substring(N,C)||d,E=r+_+t,L=m.value.substring(0,N)+E+m.value.substring(C);y(L),setTimeout(()=>{m.focus(),m.setSelectionRange(N+r.length,N+r.length+_.length)},0)},V=(()=>{const r=h||"",t=r.length;return{words:r.trim()===""?0:r.trim().split(/\s+/).length,chars:t}})(),Z=()=>{const r=new Blob([h],{type:"text/markdown;charset=utf-8;"}),t=URL.createObjectURL(r),d=document.createElement("a");d.href=t,d.setAttribute("download","document.md"),document.body.appendChild(d),d.click(),document.body.removeChild(d)},ee=()=>{const r=`<!DOCTYPE html>
<html lang="${i}">
<head>
  <meta charset="UTF-8">
  <title>Exported Document</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.6; max-width: 800px; margin: 40px auto; padding: 0 20px; color: #333; }
    pre { background: #f4f4f4; border: 1px solid #ddd; padding: 15px; border-radius: 5px; overflow-x: auto; }
    code { font-family: Courier, monospace; background: #eee; padding: 2px 4px; border-radius: 3px; }
    blockquote { border-left: 4px solid #8b5cf6; padding-left: 15px; color: #555; font-style: italic; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 8px 12px; text-align: left; }
    th { background: #f4f4f4; }
  </style>
</head>
<body>
  ${q}
</body>
</html>`,t=new Blob([r],{type:"text/html;charset=utf-8;"}),d=URL.createObjectURL(t),m=document.createElement("a");m.href=d,m.setAttribute("download","document.html"),document.body.appendChild(m),m.click(),document.body.removeChild(m)},te=()=>{navigator.clipboard.writeText(q),U(!0),setTimeout(()=>U(!1),2e3)},oe=()=>{window.print()},re=()=>{confirm("Are you sure you want to reset the editor? All current writing will be cleared.")&&y(c)};return e.jsxs("div",{className:"min-h-screen flex flex-col bg-[#030208] text-slate-200 font-sans relative overflow-x-hidden pt-24",children:[e.jsx("style",{dangerouslySetInnerHTML:{__html:`
    /* Modern Slate */
    .preview-body.theme-slate {
      color: #cbd5e1;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .preview-body.theme-slate h1, 
    .preview-body.theme-slate h2, 
    .preview-body.theme-slate h3 {
      color: #ffffff;
      font-family: 'Outfit', sans-serif;
    }

    /* Clean Journal */
    .preview-body.theme-journal {
      background-color: #fcfbf9 !important;
      color: #2d3748 !important;
      font-family: Georgia, Merriweather, serif !important;
      padding: 2.5rem !important;
      border-radius: 1rem;
    }
    .preview-body.theme-journal h1, 
    .preview-body.theme-journal h2, 
    .preview-body.theme-journal h3 {
      color: #1a202c !important;
      font-family: Georgia, serif !important;
      border-color: #e2e8f0 !important;
    }
    .preview-body.theme-journal p {
      color: #2d3748 !important;
      line-height: 1.8 !important;
    }
    .preview-body.theme-journal pre {
      background: #f7f6f3 !important;
      border: 1px solid #e2e8f0 !important;
      color: #1a202c !important;
    }
    .preview-body.theme-journal code {
      background: #f7f6f3 !important;
      color: #c026d3 !important;
      border: none !important;
    }
    .preview-body.theme-journal blockquote {
      border-color: #8b5cf6 !important;
      background: #faf5ff !important;
      color: #4a5568 !important;
    }
    .preview-body.theme-journal table {
      border-color: #e2e8f0 !important;
    }
    .preview-body.theme-journal th {
      background-color: #f7f6f3 !important;
      border-color: #e2e8f0 !important;
      color: #1a202c !important;
    }
    .preview-body.theme-journal td {
      border-color: #e2e8f0 !important;
      color: #4a5568 !important;
    }

    /* Retro Typewriter */
    .preview-body.theme-retro {
      background-color: #f5f2eb !important;
      color: #3b3a36 !important;
      font-family: 'Courier New', Courier, monospace !important;
      padding: 2.5rem !important;
      border-radius: 1rem;
      box-shadow: inset 0 0 40px rgba(0,0,0,0.05);
    }
    .preview-body.theme-retro h1, 
    .preview-body.theme-retro h2, 
    .preview-body.theme-retro h3 {
      color: #1c1b18 !important;
      font-family: 'Courier New', Courier, monospace !important;
      border-bottom: 1px dashed #b5b2a9 !important;
    }
    .preview-body.theme-retro p {
      color: #3b3a36 !important;
    }
    .preview-body.theme-retro pre {
      background: #ebe7dd !important;
      border: 1px dashed #b5b2a9 !important;
      color: #2b2a27 !important;
    }
    .preview-body.theme-retro code {
      background: #ebe7dd !important;
      color: #b91c1c !important;
      border: none !important;
    }
    .preview-body.theme-retro blockquote {
      border-color: #78716c !important;
      background: #e7e5e4/30 !important;
      color: #57534e !important;
    }
    .preview-body.theme-retro table {
      border-color: #b5b2a9 !important;
    }
    .preview-body.theme-retro th, 
    .preview-body.theme-retro td {
      border-color: #b5b2a9 !important;
      color: #3b3a36 !important;
    }

    /* Cyberpunk Neon */
    .preview-body.theme-cyberpunk {
      background-color: #05050d !important;
      color: #00ffcc !important;
      font-family: 'Courier New', Courier, monospace !important;
      border: 1px solid #ff0055;
      padding: 2.5rem !important;
      border-radius: 1rem;
      box-shadow: 0 0 20px rgba(255, 0, 85, 0.15);
    }
    .preview-body.theme-cyberpunk h1, 
    .preview-body.theme-cyberpunk h2, 
    .preview-body.theme-cyberpunk h3 {
      color: #ff0055 !important;
      text-shadow: 0 0 8px rgba(255, 0, 85, 0.6) !important;
      border-color: #ff0055 !important;
    }
    .preview-body.theme-cyberpunk p {
      color: #00ffcc !important;
    }
    .preview-body.theme-cyberpunk pre {
      background: #090915 !important;
      border: 1px solid #00ffcc !important;
      color: #00ffcc !important;
      box-shadow: 0 0 10px rgba(0, 255, 204, 0.1);
    }
    .preview-body.theme-cyberpunk code {
      background: #ff0055/10 !important;
      color: #ff0055 !important;
      border: 1px solid #ff0055/20 !important;
    }
    .preview-body.theme-cyberpunk blockquote {
      border-color: #ff0055 !important;
      background: #ff0055/10 !important;
      color: #ff0055 !important;
    }
    .preview-body.theme-cyberpunk table {
      border-color: #00ffcc !important;
    }
    .preview-body.theme-cyberpunk th, 
    .preview-body.theme-cyberpunk td {
      border-color: #00ffcc !important;
      color: #00ffcc !important;
    }
  `}}),e.jsx(Be,{currentLang:i,onLanguageChange:r=>window.location.href=`/${r.toLowerCase()}/markdown-live`,onReset:re,t:o}),e.jsxs("main",{className:"flex-grow max-w-7xl w-full mx-auto px-4 md:px-12 py-8 relative z-10 flex flex-col space-y-6",children:[e.jsx(K,{id:"adsense-markdown-live-top"}),e.jsxs("div",{className:"text-center md:text-left space-y-2",children:[e.jsxs("h2",{className:"text-3xl md:text-4xl font-extrabold tracking-tight text-white flex items-center justify-center md:justify-start gap-3",children:[e.jsx(ie,{className:"w-6 h-6 text-violet-400"}),e.jsx("span",{children:o.seoHeroTitle||"Interactive Markdown split-screen editor"})]}),e.jsx("p",{className:"text-slate-400 text-sm md:text-base max-w-3xl leading-relaxed",children:o.seoHeroText})]}),e.jsxs("div",{className:"flex flex-col flex-grow bg-slate-900/40 border border-white/5 backdrop-blur-2xl rounded-3xl overflow-hidden shadow-2xl min-h-[600px]",children:[e.jsxs("div",{className:"flex flex-col md:flex-row md:items-center justify-between p-4 bg-slate-900/80 border-b border-white/5 gap-4",children:[e.jsxs("div",{className:"flex flex-wrap items-center gap-1.5 no-print",children:[e.jsx("button",{onClick:()=>w("**","**","bold text"),title:o.tooltip_bold||"Bold",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(ge,{className:"w-4 h-4"})}),e.jsx("button",{onClick:()=>w("*","*","italic text"),title:o.tooltip_italic||"Italic",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(ke,{className:"w-4 h-4"})}),e.jsx("button",{onClick:()=>w(`
## `,"","Heading"),title:o.tooltip_heading||"Heading",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(ye,{className:"w-4 h-4"})}),e.jsx("div",{className:"w-px h-6 bg-white/10 mx-1"}),e.jsx("button",{onClick:()=>w("[","](https://example.com)","link text"),title:o.tooltip_link||"Link",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(ae,{className:"w-4 h-4"})}),e.jsx("button",{onClick:()=>w("![","](https://example.com/image.png)","Image Alt"),title:o.tooltip_image||"Image",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(ce,{className:"w-4 h-4"})}),e.jsx("button",{onClick:()=>w("`","`","code"),title:o.tooltip_code||"Inline Code",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(de,{className:"w-4 h-4"})}),e.jsx("button",{onClick:()=>w("\n```javascript\n","\n```\n","// code snippet"),title:o.tooltip_codeblock||"Code Block",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(Se,{className:"w-4 h-4"})}),e.jsx("div",{className:"w-px h-6 bg-white/10 mx-1"}),e.jsx("button",{onClick:()=>w(`
> `,"","Blockquote text"),title:o.tooltip_quote||"Blockquote",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(Te,{className:"w-4 h-4"})}),e.jsx("button",{onClick:()=>w(`
- `,"","list item"),title:o.tooltip_ul||"Unordered List",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(me,{className:"w-4 h-4"})}),e.jsx("button",{onClick:()=>w(`
1. `,"","list item"),title:o.tooltip_ol||"Ordered List",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(he,{className:"w-4 h-4"})}),e.jsx("button",{onClick:()=>w(`
| Header 1 | Header 2 |
| :--- | :---: |
| Cell 1 | Cell 2 |
`),title:o.tooltip_table||"Table",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(Le,{className:"w-4 h-4"})}),e.jsx("button",{onClick:()=>w(`
---
`),title:o.tooltip_hr||"Horizontal Rule",className:"w-9 h-9 flex items-center justify-center rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-slate-300 hover:text-white transition-all cursor-pointer outline-none",children:e.jsx(pe,{className:"w-4 h-4"})})]}),e.jsxs("div",{className:"flex flex-wrap items-center gap-4 no-print",children:[e.jsxs("div",{className:"flex items-center space-x-2 bg-slate-950/40 px-3 py-1.5 rounded-xl border border-white/5",children:[e.jsx(xe,{className:"w-4 h-4 text-violet-400"}),e.jsxs("span",{className:"text-xs font-semibold text-slate-400",children:[o.style_label||"Skin",":"]}),e.jsxs("select",{value:$,onChange:r=>Y(r.target.value),className:"bg-transparent border-none text-xs text-white font-bold cursor-pointer outline-none focus:ring-0",children:[e.jsx("option",{value:"slate",className:"bg-slate-900 text-white",children:o.style_default||"Default Slate"}),e.jsx("option",{value:"journal",className:"bg-slate-900 text-white",children:o.style_clean||"Clean Journal"}),e.jsx("option",{value:"retro",className:"bg-slate-900 text-white",children:o.style_retro||"Retro Typewriter"}),e.jsx("option",{value:"cyberpunk",className:"bg-slate-900 text-white",children:o.style_cyberpunk||"Cyberpunk Neon"})]})]}),e.jsxs("div",{className:"flex items-center bg-slate-950/60 p-1 rounded-xl border border-white/5",children:[e.jsxs("button",{onClick:()=>f("preview"),className:`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer outline-none flex items-center space-x-1.5 ${p==="preview"?"bg-violet-600 text-white shadow-lg shadow-violet-600/30":"text-slate-400 hover:text-white"}`,children:[e.jsx(be,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:o.preview_mode||"Preview Pane"})]}),e.jsxs("button",{onClick:()=>f("html"),className:`px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer outline-none flex items-center space-x-1.5 ${p==="html"?"bg-violet-600 text-white shadow-lg shadow-violet-600/30":"text-slate-400 hover:text-white"}`,children:[e.jsx(J,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:o.html_mode||"Raw HTML"})]})]})]})]}),e.jsxs("div",{className:"flex flex-col md:flex-row flex-grow min-h-[500px]",children:[e.jsx("div",{className:"w-full md:w-1/2 flex flex-col border-b md:border-b-0 md:border-r border-white/5 relative bg-slate-950/20 no-print",children:e.jsx("textarea",{ref:R,value:h,onChange:r=>y(r.target.value),onScroll:Q,placeholder:"Type some markdown here...",className:"w-full flex-grow p-6 md:p-8 bg-transparent text-slate-300 font-mono text-sm resize-none border-none outline-none focus:ring-0 focus:border-none scrollbar-thin"})}),e.jsx("div",{className:"w-full md:w-1/2 flex flex-col relative bg-slate-950/45 overflow-hidden",children:e.jsx("div",{ref:D,onScroll:X,className:"w-full flex-grow p-6 md:p-8 overflow-y-auto scrollbar-thin print-document-content preview-panel",children:p==="preview"?e.jsx("div",{className:`preview-body theme-${$} prose prose-invert max-w-none transition-all duration-300`,dangerouslySetInnerHTML:{__html:q}}):e.jsx("pre",{className:"bg-transparent text-emerald-400 font-mono text-xs overflow-x-auto whitespace-pre-wrap leading-relaxed select-all",children:q})})})]}),e.jsxs("div",{className:"flex flex-col sm:flex-row sm:items-center justify-between px-6 py-4 bg-slate-900/60 border-t border-white/5 text-xs text-slate-400 gap-4 no-print",children:[e.jsxs("div",{className:"flex items-center space-x-4",children:[e.jsxs("span",{className:"flex items-center space-x-1",children:[e.jsx("span",{className:"text-white font-bold",children:V.words}),e.jsx("span",{className:"opacity-60",children:o.words||"words"})]}),e.jsx("span",{className:"w-px h-3.5 bg-white/10"}),e.jsxs("span",{className:"flex items-center space-x-1",children:[e.jsx("span",{className:"text-white font-bold",children:V.chars}),e.jsx("span",{className:"opacity-60",children:o.characters||"characters"})]})]}),e.jsxs("div",{className:"flex flex-wrap items-center gap-2",children:[e.jsxs("button",{onClick:Z,className:"flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-white transition-all cursor-pointer outline-none",children:[e.jsx(ue,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:o.btn_download_md||"Download MD"})]}),e.jsxs("button",{onClick:ee,className:"flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 border border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-white transition-all cursor-pointer outline-none",children:[e.jsx(J,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:o.btn_download_html||"Download HTML"})]}),e.jsxs("button",{onClick:te,className:`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border transition-all cursor-pointer outline-none ${W?"bg-emerald-500/20 border-emerald-500/50 text-emerald-400":"bg-white/5 border-white/5 hover:bg-violet-500/20 hover:border-violet-500/30 text-white"}`,children:[e.jsx(fe,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:W?o.copied||"Copied!":o.btn_copy_html||"Copy HTML"})]}),e.jsxs("button",{onClick:oe,className:"flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white font-bold transition-all cursor-pointer outline-none shadow-lg shadow-violet-600/20",children:[e.jsx(Ce,{className:"w-3.5 h-3.5"}),e.jsx("span",{children:o.btn_download_pdf||"Export PDF"})]})]})]})]}),e.jsx(K,{id:"adsense-markdown-live-bottom"})]}),e.jsx(Re,{lang:i,t:o,onOpenModal:r=>B(r)}),e.jsx(F,{isOpen:A==="privacy",onClose:()=>B(null),title:j[i]?.privacy.title||"Privacy Policy",content:j[i]?.privacy.content,t:o}),e.jsx(F,{isOpen:A==="terms",onClose:()=>B(null),title:j[i]?.terms.title||"Terms of Service",content:j[i]?.terms.content,t:o}),e.jsx(F,{isOpen:A==="cookies",onClose:()=>B(null),title:j[i]?.cookies.title||"Cookie Policy",content:j[i]?.cookies.content,t:o})]})}export{st as default};
