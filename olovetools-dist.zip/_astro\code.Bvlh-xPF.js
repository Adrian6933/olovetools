import{c as o}from"./createLucideIcon.D7mwnnQi.js";const e=[["path",{d:"m16 18 6-6-6-6",key:"eg8j8"}],["path",{d:"m8 6-6 6 6 6",key:"ppft3o"}]],t=o("code",e);export{t as C};
